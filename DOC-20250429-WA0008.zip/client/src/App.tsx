import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import HolidayPage from "@/pages/holiday-page";
import StreakPage from "@/pages/streak-page";
import SyllabusPage from "@/pages/syllabus-page";
import MarksPage from "@/pages/marks-page";
import CalendarPage from "@/pages/calendar-page";
import BacklogPage from "@/pages/backlog-page";
import AchievementsPage from "@/pages/achievements-page";
import PomodoroPage from "@/pages/pomodoro-page";
import SummaryPage from "@/pages/summary-page";
import SettingsPage from "@/pages/settings-page";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/holidays" component={HolidayPage} />
      <Route path="/streak" component={StreakPage} />
      <Route path="/syllabus" component={SyllabusPage} />
      <Route path="/marks" component={MarksPage} />
      <Route path="/calendar" component={CalendarPage} />
      <Route path="/backlog" component={BacklogPage} />
      <Route path="/achievements" component={AchievementsPage} />
      <Route path="/pomodoro" component={PomodoroPage} />
      <Route path="/summary" component={SummaryPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
