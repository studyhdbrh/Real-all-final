import { AppLayout } from "@/components/layout/app-layout";
import { SyllabusTracker } from "@/components/syllabus/syllabus-tracker";

export default function SyllabusPage() {
  return (
    <AppLayout title="Syllabus Tracker">
      <SyllabusTracker />
    </AppLayout>
  );
}
