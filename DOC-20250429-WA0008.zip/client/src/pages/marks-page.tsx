import { AppLayout } from "@/components/layout/app-layout";
import { MarksTracker } from "@/components/tests/marks-tracker";

export default function MarksPage() {
  return (
    <AppLayout title="Marks Tracker">
      <MarksTracker />
    </AppLayout>
  );
}
