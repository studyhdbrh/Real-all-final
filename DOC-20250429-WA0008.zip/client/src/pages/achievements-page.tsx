import { AppLayout } from "@/components/layout/app-layout";
import { AchievementsList } from "@/components/achievements/achievements-list";

export default function AchievementsPage() {
  return (
    <AppLayout title="Achievements">
      <AchievementsList />
    </AppLayout>
  );
}
