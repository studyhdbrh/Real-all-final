import { AppLayout } from "@/components/layout/app-layout";
import { PomodoroPage as PomodoroComponent } from "@/components/pomodoro/pomodoro-page";

export default function PomodoroPage() {
  return (
    <AppLayout title="Pomodoro Timer">
      <PomodoroComponent />
    </AppLayout>
  );
}
