import { AppLayout } from "@/components/layout/app-layout";
import { SettingsPage as SettingsComponent } from "@/components/settings/settings-page";

export default function SettingsPage() {
  return (
    <AppLayout title="Settings">
      <SettingsComponent />
    </AppLayout>
  );
}
