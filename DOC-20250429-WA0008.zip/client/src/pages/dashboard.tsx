import { AppLayout } from "@/components/layout/app-layout";
import { TodaysTasks } from "@/components/dashboard/today-tasks";
import { SyllabusProgress } from "@/components/dashboard/syllabus-progress";
import { RecentTestMarks } from "@/components/dashboard/recent-test-marks";
import { DailyGoals } from "@/components/dashboard/daily-goals";
import { StreakManager } from "@/components/dashboard/streak-manager";
import { PomodoroTimer } from "@/components/dashboard/pomodoro-timer";
import { BacklogTasks } from "@/components/dashboard/backlog-tasks";

export default function Dashboard() {
  return (
    <AppLayout title="Dashboard">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-6">
          <TodaysTasks />
          <SyllabusProgress />
          <RecentTestMarks />
        </div>

        {/* Right column */}
        <div className="space-y-6">
          <DailyGoals />
          <StreakManager />
          <PomodoroTimer />
          <BacklogTasks />
        </div>
      </div>
    </AppLayout>
  );
}
