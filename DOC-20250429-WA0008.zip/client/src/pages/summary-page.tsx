import { AppLayout } from "@/components/layout/app-layout";
import { DailyWeeklySummary } from "@/components/summary/daily-weekly-summary";

export default function SummaryPage() {
  return (
    <AppLayout title="Summary Reports">
      <DailyWeeklySummary />
    </AppLayout>
  );
}
