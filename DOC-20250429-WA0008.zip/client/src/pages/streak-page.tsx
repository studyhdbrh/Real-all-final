import { useState } from "react";
import { AppLayout } from "@/components/layout/app-layout";
import { useStreak } from "@/hooks/use-streak";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Award, Flame, Calendar, Trophy } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format, parseISO } from "date-fns";
import { cn } from "@/lib/utils";

export default function StreakPage() {
  const { streakData, updateStreakDay } = useStreak();
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());

  // Create a calendar for the current month
  const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(selectedYear, selectedMonth, 1).getDay();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  
  // Create weeks array
  const weeks: number[][] = [];
  let currentWeek: number[] = [];
  
  // Add empty days for the first week
  for (let i = 0; i < firstDayOfMonth; i++) {
    currentWeek.push(0); // 0 represents an empty day
  }
  
  // Add all days
  days.forEach((day) => {
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
    currentWeek.push(day);
  });
  
  // Fill the last week with empty days
  while (currentWeek.length < 7) {
    currentWeek.push(0);
  }
  weeks.push(currentWeek);
  
  const handlePrevMonth = () => {
    if (selectedMonth === 0) {
      setSelectedMonth(11);
      setSelectedYear(selectedYear - 1);
    } else {
      setSelectedMonth(selectedMonth - 1);
    }
  };
  
  const handleNextMonth = () => {
    if (selectedMonth === 11) {
      setSelectedMonth(0);
      setSelectedYear(selectedYear + 1);
    } else {
      setSelectedMonth(selectedMonth + 1);
    }
  };
  
  const getDayStatus = (day: number): 'completed' | 'holiday' | 'missed' | null => {
    if (day === 0) return null;
    
    const dateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const streakDay = streakData.lastTwoWeeks.find(d => d.date === dateStr);
    
    return streakDay?.status || null;
  };
  
  const getLongestStreakPeriod = () => {
    if (streakData.bestStreak === 0) return "No streak yet";
    
    // This is a placeholder - in a real app, you would track the actual period
    return `${streakData.bestStreak} consecutive days`;
  };

  return (
    <AppLayout title="Streak Manager">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Streak Calendar</CardTitle>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={handlePrevMonth}>
                  Previous
                </Button>
                <Button variant="outline" size="sm" onClick={handleNextMonth}>
                  Next
                </Button>
              </div>
            </div>
            <CardDescription>
              {format(new Date(selectedYear, selectedMonth, 1), 'MMMM yyyy')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-1 mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="text-center text-sm font-medium text-gray-500 py-1">
                  {day}
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-7 gap-1">
              {weeks.flat().map((day, i) => {
                const status = getDayStatus(day);
                
                return (
                  <div
                    key={i}
                    className={cn(
                      "h-14 rounded-md flex items-center justify-center",
                      day === 0 ? "bg-transparent" : "bg-background dark:bg-gray-800",
                      status === 'completed' && "bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300",
                      status === 'holiday' && "bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300",
                      status === 'missed' && "bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300",
                      day === new Date().getDate() && 
                      selectedMonth === new Date().getMonth() && 
                      selectedYear === new Date().getFullYear() && 
                      "border-2 border-primary"
                    )}
                  >
                    {day !== 0 && (
                      <span className="text-sm font-medium">{day}</span>
                    )}
                  </div>
                );
              })}
            </div>
            
            <div className="flex justify-center space-x-6 text-xs mt-4">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-100 dark:bg-green-900 rounded-full mr-1"></div>
                <span>Completed</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-amber-100 dark:bg-amber-900 rounded-full mr-1"></div>
                <span>Holiday</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-red-100 dark:bg-red-900 rounded-full mr-1"></div>
                <span>Missed</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Current Streak</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center">
                <div className="text-5xl font-bold text-primary mb-2">{streakData.currentStreak}</div>
                <div className="text-sm text-muted-foreground">consecutive days</div>
                
                <div className="mt-6 flex items-center">
                  <Flame className="h-5 w-5 text-amber-500 mr-2" />
                  <span className="font-medium">Keep it going!</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Streak Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <Trophy className="h-5 w-5 text-amber-500 mr-2" />
                  <span>Best Streak</span>
                </div>
                <Badge variant="secondary">{streakData.bestStreak} days</Badge>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-primary mr-2" />
                  <span>Period</span>
                </div>
                <span className="text-sm">{getLongestStreakPeriod()}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <Award className="h-5 w-5 text-green-500 mr-2" />
                  <span>Achievement Level</span>
                </div>
                <Badge variant={streakData.bestStreak >= 30 ? "destructive" : 
                       streakData.bestStreak >= 10 ? "secondary" : "outline"}>
                  {streakData.bestStreak >= 30 ? "Master" : 
                   streakData.bestStreak >= 10 ? "Intermediate" : 
                   streakData.bestStreak >= 5 ? "Beginner" : "Novice"}
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Next Milestones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {streakData.currentStreak < 5 && (
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Award className="h-5 w-5 text-amber-500 mr-2" />
                      <span>5 Days Streak</span>
                    </div>
                    <Badge variant="outline">{5 - streakData.currentStreak} days left</Badge>
                  </div>
                )}
                
                {streakData.currentStreak < 10 && (
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Award className="h-5 w-5 text-amber-500 mr-2" />
                      <span>10 Days Streak</span>
                    </div>
                    <Badge variant="outline">{10 - streakData.currentStreak} days left</Badge>
                  </div>
                )}
                
                {streakData.currentStreak < 30 && (
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Award className="h-5 w-5 text-amber-500 mr-2" />
                      <span>30 Days Streak</span>
                    </div>
                    <Badge variant="outline">{30 - streakData.currentStreak} days left</Badge>
                  </div>
                )}
                
                {streakData.currentStreak >= 30 && (
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Award className="h-5 w-5 text-amber-500 mr-2" />
                      <span>All milestones reached!</span>
                    </div>
                    <Badge variant="success">Completed</Badge>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
