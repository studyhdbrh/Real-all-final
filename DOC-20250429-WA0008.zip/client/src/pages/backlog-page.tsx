import { AppLayout } from "@/components/layout/app-layout";
import { BacklogManager } from "@/components/backlog/backlog-manager";

export default function BacklogPage() {
  return (
    <AppLayout title="Backlog Manager">
      <BacklogManager />
    </AppLayout>
  );
}
