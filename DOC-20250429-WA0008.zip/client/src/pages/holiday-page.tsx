import { AppLayout } from "@/components/layout/app-layout";
import { HolidayManager } from "@/components/holidays/holiday-manager";

export default function HolidayPage() {
  return (
    <AppLayout title="Holiday Manager">
      <HolidayManager />
    </AppLayout>
  );
}
