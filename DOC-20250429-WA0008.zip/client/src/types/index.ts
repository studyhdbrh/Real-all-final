// Task types
export interface Task {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  date: string;
  isCompleted: boolean;
  actualTimeTaken?: number; // in minutes
  isImportant?: boolean;
  isCritical?: boolean;
}

// Holiday types
export interface Holiday {
  id: string;
  date: string;
  reason: string;
  isFullDay: boolean;
  hours?: number;
}

// Streak types
export interface StreakDay {
  date: string;
  status: 'completed' | 'holiday' | 'missed';
}

export interface StreakData {
  currentStreak: number;
  bestStreak: number;
  lastTwoWeeks: StreakDay[];
}

// Syllabus types
export interface Chapter {
  id: string;
  name: string;
  isCompletedMain: boolean;
  isCompletedAdvanced: boolean;
}

export interface Subject {
  id: string;
  name: string;
  chapters: Chapter[];
  mainProgress: number; // Percentage
  advancedProgress: number; // Percentage
}

// Test types
export interface Test {
  id: string;
  date: string;
  subject: string;
  topic: string;
  score: number; // Out of 60
  maxScore: number;
  change: number; // +ve or -ve
}

// Daily Goal types
export interface DailyGoal {
  id: string;
  name: string;
  target: number;
  current: number;
  unit: string;
}

// User Profile type
export interface UserProfile {
  name: string;
  className: string;
  examName: string;
  photoUrl?: string;
}

// Backlog Task types
export interface BacklogTask {
  id: string;
  title: string;
  description?: string;
  pendingFromDate: string;
  originalDate: string;
}

// Achievement types
export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  isUnlocked: boolean;
  unlockedDate?: string;
}

// Pomodoro types
export interface PomodoroSettings {
  focusTime: number; // in minutes
  breakTime: number; // in minutes
  cycles: number;
}

export interface PomodoroState {
  isActive: boolean;
  isPaused: boolean;
  isBreak: boolean;
  timeLeft: number; // in seconds
  currentCycle: number;
  totalCycles: number;
}

// Summary types
export interface DailySummary {
  date: string;
  tasksCompleted: number;
  totalTasks: number;
  studyHours: number;
  achievements: string[];
}

export interface WeeklySummary {
  weekStartDate: string;
  weekEndDate: string;
  tasksCompleted: number;
  totalTasks: number;
  studyHours: number;
  achievements: string[];
  streakMaintained: boolean;
}
