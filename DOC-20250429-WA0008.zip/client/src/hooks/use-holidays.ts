import { useCallback } from 'react';
import { Holiday } from '@/types';
import useLocalStorage from './use-local-storage';
import { generateId } from '@/lib/utils';

export function useHolidays() {
  const [holidays, setHolidays] = useLocalStorage<Holiday[]>('study-track-holidays', []);
  
  const addHoliday = useCallback((holiday: Omit<Holiday, 'id'>) => {
    setHolidays(prevHolidays => [...prevHolidays, { ...holiday, id: generateId() }]);
  }, [setHolidays]);
  
  const deleteHoliday = useCallback((holidayId: string) => {
    setHolidays(prevHolidays => prevHolidays.filter(holiday => holiday.id !== holidayId));
  }, [setHolidays]);
  
  const getHolidaysByMonth = useCallback((year: number, month: number) => {
    // Month in JS is 0-based, but we accept 1-based for user friendliness
    const startDate = new Date(year, month - 1, 1).toISOString().split('T')[0];
    const endDate = new Date(year, month, 0).toISOString().split('T')[0];
    
    return holidays.filter(holiday => 
      holiday.date >= startDate && holiday.date <= endDate
    );
  }, [holidays]);
  
  const isHolidayAvailable = useCallback((year: number, month: number) => {
    const holidaysInMonth = getHolidaysByMonth(year, month);
    // Maximum 7 holidays allowed per month
    return holidaysInMonth.length < 7;
  }, [getHolidaysByMonth]);
  
  const getHolidayByDate = useCallback((date: string) => {
    return holidays.find(holiday => holiday.date === date);
  }, [holidays]);

  const importHolidays = useCallback((importedHolidays: Holiday[]) => {
    setHolidays(importedHolidays);
  }, [setHolidays]);
  
  return {
    holidays,
    addHoliday,
    deleteHoliday,
    getHolidaysByMonth,
    isHolidayAvailable,
    getHolidayByDate,
    importHolidays
  };
}
