import { useCallback } from 'react';
import { Task } from '@/types';
import useLocalStorage from './use-local-storage';
import { generateId, getToday } from '@/lib/utils';

export function useTasks() {
  const [tasks, setTasks] = useLocalStorage<Task[]>('study-track-tasks', []);
  
  const getTodaysTasks = useCallback(() => {
    const today = getToday();
    return tasks.filter(task => task.date === today);
  }, [tasks]);
  
  const getBacklogTasks = useCallback(() => {
    const today = getToday();
    return tasks.filter(task => !task.isCompleted && task.date < today);
  }, [tasks]);
  
  const getTasksByDate = useCallback((date: string) => {
    return tasks.filter(task => task.date === date);
  }, [tasks]);
  
  const addTask = useCallback((task: Omit<Task, 'id'>) => {
    setTasks(prevTasks => [...prevTasks, { ...task, id: generateId() }]);
  }, [setTasks]);
  
  const updateTask = useCallback((taskId: string, updatedTask: Partial<Task>) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId ? { ...task, ...updatedTask } : task
      )
    );
  }, [setTasks]);
  
  const deleteTask = useCallback((taskId: string) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
  }, [setTasks]);
  
  const markTaskAsComplete = useCallback((taskId: string, actualTimeTaken: number) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId ? { ...task, isCompleted: true, actualTimeTaken } : task
      )
    );
  }, [setTasks]);
  
  const moveTaskToToday = useCallback((taskId: string) => {
    const today = getToday();
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId ? { ...task, date: today } : task
      )
    );
  }, [setTasks]);
  
  const importTasks = useCallback((importedTasks: Task[]) => {
    setTasks(importedTasks);
  }, [setTasks]);

  return {
    tasks,
    getTodaysTasks,
    getBacklogTasks,
    getTasksByDate,
    addTask,
    updateTask,
    deleteTask,
    markTaskAsComplete,
    moveTaskToToday,
    importTasks
  };
}
