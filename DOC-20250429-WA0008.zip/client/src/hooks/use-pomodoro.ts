import { useState, useCallback, useEffect, useRef } from 'react';
import { PomodoroSettings, PomodoroState } from '@/types';
import useLocalStorage from './use-local-storage';

export function usePomodoro() {
  const [settings, setSettings] = useLocalStorage<PomodoroSettings>('study-track-pomodoro-settings', {
    focusTime: 25, // 25 minutes
    breakTime: 5,  // 5 minutes
    cycles: 4
  });
  
  const [state, setState] = useState<PomodoroState>({
    isActive: false,
    isPaused: false,
    isBreak: false,
    timeLeft: settings.focusTime * 60, // convert to seconds
    currentCycle: 1,
    totalCycles: settings.cycles
  });
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Clear interval on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);
  
  // Update timeLeft when settings change
  useEffect(() => {
    if (!state.isActive) {
      setState(prev => ({
        ...prev,
        timeLeft: prev.isBreak ? settings.breakTime * 60 : settings.focusTime * 60,
        totalCycles: settings.cycles
      }));
    }
  }, [settings, state.isActive, state.isBreak]);
  
  const start = useCallback(() => {
    setState(prev => ({ ...prev, isActive: true, isPaused: false }));
    
    intervalRef.current = setInterval(() => {
      setState(prev => {
        if (prev.timeLeft <= 1) {
          // Time's up, switch between focus and break or move to next cycle
          if (prev.isBreak) {
            // Break is over
            if (prev.currentCycle >= prev.totalCycles) {
              // All cycles completed
              if (intervalRef.current) {
                clearInterval(intervalRef.current);
              }
              
              return {
                ...prev,
                isActive: false,
                isPaused: false,
                isBreak: false,
                timeLeft: settings.focusTime * 60,
                currentCycle: 1
              };
            } else {
              // Move to next cycle
              return {
                ...prev,
                isBreak: false,
                timeLeft: settings.focusTime * 60,
                currentCycle: prev.currentCycle + 1
              };
            }
          } else {
            // Focus time is over, start break
            return {
              ...prev,
              isBreak: true,
              timeLeft: settings.breakTime * 60
            };
          }
        } else {
          // Just decrement the time
          return {
            ...prev,
            timeLeft: prev.timeLeft - 1
          };
        }
      });
    }, 1000);
  }, [settings]);
  
  const pause = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    setState(prev => ({ ...prev, isPaused: true }));
  }, []);
  
  const resume = useCallback(() => {
    setState(prev => ({ ...prev, isPaused: false }));
    start();
  }, [start]);
  
  const reset = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    setState({
      isActive: false,
      isPaused: false,
      isBreak: false,
      timeLeft: settings.focusTime * 60,
      currentCycle: 1,
      totalCycles: settings.cycles
    });
  }, [settings]);
  
  const updateSettings = useCallback((newSettings: Partial<PomodoroSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, [setSettings]);
  
  const importSettings = useCallback((importedSettings: PomodoroSettings) => {
    setSettings(importedSettings);
    reset();
  }, [setSettings, reset]);
  
  return {
    state,
    settings,
    start,
    pause,
    resume,
    reset,
    updateSettings,
    importSettings
  };
}
