import { useCallback } from 'react';
import { StreakDay, StreakData } from '@/types';
import useLocalStorage from './use-local-storage';
import { getLast14Days, getToday } from '@/lib/utils';

export function useStreak() {
  const [streakData, setStreakData] = useLocalStorage<StreakData>('study-track-streak', {
    currentStreak: 0,
    bestStreak: 0,
    lastTwoWeeks: getLast14Days().map(date => ({ 
      date, 
      status: getToday() >= date ? 'missed' : 'completed' 
    }))
  });
  
  const updateStreakDay = useCallback((date: string, status: 'completed' | 'holiday' | 'missed') => {
    setStreakData(prevData => {
      const lastTwoWeeks = [...prevData.lastTwoWeeks];
      const dayIndex = lastTwoWeeks.findIndex(day => day.date === date);
      
      if (dayIndex !== -1) {
        lastTwoWeeks[dayIndex] = { ...lastTwoWeeks[dayIndex], status };
      }
      
      let currentStreak = calculateCurrentStreak(lastTwoWeeks);
      const bestStreak = Math.max(prevData.bestStreak, currentStreak);
      
      return {
        currentStreak,
        bestStreak,
        lastTwoWeeks
      };
    });
  }, [setStreakData]);
  
  const calculateCurrentStreak = (days: StreakDay[]): number => {
    // Sort days by date
    const sortedDays = [...days].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    let streak = 0;
    const today = getToday();
    
    // Start counting from today backwards
    for (const day of sortedDays) {
      if (day.date > today) continue; // Skip future days
      
      if (day.status === 'completed' || day.status === 'holiday') {
        streak++;
      } else {
        break; // Break the streak on missed day
      }
    }
    
    return streak;
  };
  
  const refreshStreakDays = useCallback(() => {
    const last14Days = getLast14Days();
    
    setStreakData(prevData => {
      // Create a map of existing days
      const existingDaysMap = new Map(
        prevData.lastTwoWeeks.map(day => [day.date, day])
      );
      
      // Create new lastTwoWeeks array
      const lastTwoWeeks = last14Days.map(date => 
        existingDaysMap.has(date) 
          ? existingDaysMap.get(date)!
          : { date, status: 'missed' as const }
      );
      
      let currentStreak = calculateCurrentStreak(lastTwoWeeks);
      const bestStreak = Math.max(prevData.bestStreak, currentStreak);
      
      return {
        currentStreak,
        bestStreak,
        lastTwoWeeks
      };
    });
  }, [setStreakData]);
  
  const importStreakData = useCallback((importedStreakData: StreakData) => {
    setStreakData(importedStreakData);
  }, [setStreakData]);
  
  return {
    streakData,
    updateStreakDay,
    refreshStreakDays,
    importStreakData
  };
}
