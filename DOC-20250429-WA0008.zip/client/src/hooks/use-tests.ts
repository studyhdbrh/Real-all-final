import { useCallback } from 'react';
import { Test } from '@/types';
import useLocalStorage from './use-local-storage';
import { generateId } from '@/lib/utils';

export function useTests() {
  const [tests, setTests] = useLocalStorage<Test[]>('study-track-tests', []);
  
  const addTest = useCallback((test: Omit<Test, 'id' | 'change'>) => {
    // Calculate change by comparing with previous test of same subject
    const previousTests = tests
      .filter(t => t.subject === test.subject)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    const previousTest = previousTests[0];
    const previousScore = previousTest ? previousTest.score : 0;
    const change = test.score - previousScore;
    
    const newTest = {
      id: generateId(),
      ...test,
      change
    };
    
    setTests(prevTests => [...prevTests, newTest]);
    return newTest;
  }, [tests, setTests]);
  
  const updateTest = useCallback((testId: string, updatedTest: Partial<Omit<Test, 'change'>>) => {
    setTests(prevTests => {
      const updatedTests = prevTests.map(test => {
        if (test.id === testId) {
          // If score is being updated, recalculate change
          if (updatedTest.score !== undefined) {
            const previousTests = prevTests
              .filter(t => t.subject === test.subject && t.id !== test.id && new Date(t.date) < new Date(test.date))
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
            
            const previousTest = previousTests[0];
            const previousScore = previousTest ? previousTest.score : 0;
            const change = updatedTest.score - previousScore;
            
            return { ...test, ...updatedTest, change };
          }
          
          return { ...test, ...updatedTest };
        }
        return test;
      });
      
      return updatedTests;
    });
  }, [setTests]);
  
  const deleteTest = useCallback((testId: string) => {
    setTests(prevTests => {
      // Get the test being deleted
      const testToDelete = prevTests.find(test => test.id === testId);
      if (!testToDelete) return prevTests;
      
      // Remove the test
      const filteredTests = prevTests.filter(test => test.id !== testId);
      
      // Recalculate change for subsequent tests of the same subject
      const subsequentTests = filteredTests
        .filter(test => 
          test.subject === testToDelete.subject && 
          new Date(test.date) > new Date(testToDelete.date)
        )
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
      if (subsequentTests.length === 0) return filteredTests;
      
      // Get the previous test before the first subsequent test
      const firstSubsequentTest = subsequentTests[0];
      const previousTests = filteredTests
        .filter(test => 
          test.subject === firstSubsequentTest.subject && 
          new Date(test.date) < new Date(firstSubsequentTest.date)
        )
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      const previousScore = previousTests.length > 0 ? previousTests[0].score : 0;
      
      // Update changes for all subsequent tests
      let lastScore = previousScore;
      
      return filteredTests.map(test => {
        if (subsequentTests.some(st => st.id === test.id)) {
          const change = test.score - lastScore;
          lastScore = test.score;
          return { ...test, change };
        }
        return test;
      });
    });
  }, [setTests]);
  
  const getRecentTests = useCallback((limit: number = 5) => {
    return [...tests]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, limit);
  }, [tests]);
  
  const getTestsBySubject = useCallback((subject: string) => {
    return tests
      .filter(test => test.subject === subject)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [tests]);
  
  const getAverageScore = useCallback((subject?: string) => {
    const filteredTests = subject 
      ? tests.filter(test => test.subject === subject)
      : tests;
    
    if (filteredTests.length === 0) return 0;
    
    const totalScore = filteredTests.reduce((sum, test) => sum + test.score, 0);
    return Math.round((totalScore / filteredTests.length) * 10) / 10;
  }, [tests]);
  
  const importTests = useCallback((importedTests: Test[]) => {
    setTests(importedTests);
  }, [setTests]);
  
  return {
    tests,
    addTest,
    updateTest,
    deleteTest,
    getRecentTests,
    getTestsBySubject,
    getAverageScore,
    importTests
  };
}
