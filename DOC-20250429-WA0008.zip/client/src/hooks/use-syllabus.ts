import { useCallback } from 'react';
import { Subject, Chapter } from '@/types';
import useLocalStorage from './use-local-storage';
import { generateId } from '@/lib/utils';

export function useSyllabus() {
  const [subjects, setSubjects] = useLocalStorage<Subject[]>('study-track-syllabus', []);
  
  const calculateProgress = useCallback((chapters: Chapter[], level: 'main' | 'advanced') => {
    if (chapters.length === 0) return 0;
    
    const completedChapters = chapters.filter(chapter => 
      level === 'main' ? chapter.isCompletedMain : chapter.isCompletedAdvanced
    ).length;
    
    return Math.round((completedChapters / chapters.length) * 100);
  }, []);
  
  const updateSubjectProgress = useCallback((subjectId: string) => {
    setSubjects(prevSubjects => 
      prevSubjects.map(subject => {
        if (subject.id === subjectId) {
          const mainProgress = calculateProgress(subject.chapters, 'main');
          const advancedProgress = calculateProgress(subject.chapters, 'advanced');
          
          return {
            ...subject,
            mainProgress,
            advancedProgress
          };
        }
        return subject;
      })
    );
  }, [setSubjects, calculateProgress]);
  
  const addSubject = useCallback((name: string) => {
    const newSubject: Subject = {
      id: generateId(),
      name,
      chapters: [],
      mainProgress: 0,
      advancedProgress: 0
    };
    
    setSubjects(prevSubjects => [...prevSubjects, newSubject]);
    return newSubject.id;
  }, [setSubjects]);
  
  const updateSubject = useCallback((subjectId: string, name: string) => {
    setSubjects(prevSubjects => 
      prevSubjects.map(subject => 
        subject.id === subjectId ? { ...subject, name } : subject
      )
    );
  }, [setSubjects]);
  
  const deleteSubject = useCallback((subjectId: string) => {
    setSubjects(prevSubjects => prevSubjects.filter(subject => subject.id !== subjectId));
  }, [setSubjects]);
  
  const addChapter = useCallback((subjectId: string, name: string) => {
    const newChapter: Chapter = {
      id: generateId(),
      name,
      isCompletedMain: false,
      isCompletedAdvanced: false
    };
    
    setSubjects(prevSubjects => 
      prevSubjects.map(subject => {
        if (subject.id === subjectId) {
          const updatedChapters = [...subject.chapters, newChapter];
          return {
            ...subject,
            chapters: updatedChapters,
            mainProgress: calculateProgress(updatedChapters, 'main'),
            advancedProgress: calculateProgress(updatedChapters, 'advanced')
          };
        }
        return subject;
      })
    );
    
    return newChapter.id;
  }, [setSubjects, calculateProgress]);
  
  const updateChapter = useCallback((subjectId: string, chapterId: string, updates: Partial<Chapter>) => {
    setSubjects(prevSubjects => 
      prevSubjects.map(subject => {
        if (subject.id === subjectId) {
          const updatedChapters = subject.chapters.map(chapter => 
            chapter.id === chapterId ? { ...chapter, ...updates } : chapter
          );
          
          return {
            ...subject,
            chapters: updatedChapters,
            mainProgress: calculateProgress(updatedChapters, 'main'),
            advancedProgress: calculateProgress(updatedChapters, 'advanced')
          };
        }
        return subject;
      })
    );
  }, [setSubjects, calculateProgress]);
  
  const deleteChapter = useCallback((subjectId: string, chapterId: string) => {
    setSubjects(prevSubjects => 
      prevSubjects.map(subject => {
        if (subject.id === subjectId) {
          const updatedChapters = subject.chapters.filter(chapter => chapter.id !== chapterId);
          
          return {
            ...subject,
            chapters: updatedChapters,
            mainProgress: calculateProgress(updatedChapters, 'main'),
            advancedProgress: calculateProgress(updatedChapters, 'advanced')
          };
        }
        return subject;
      })
    );
  }, [setSubjects, calculateProgress]);
  
  const toggleChapterCompletion = useCallback((
    subjectId: string, 
    chapterId: string, 
    level: 'main' | 'advanced'
  ) => {
    setSubjects(prevSubjects => 
      prevSubjects.map(subject => {
        if (subject.id === subjectId) {
          const updatedChapters = subject.chapters.map(chapter => {
            if (chapter.id === chapterId) {
              if (level === 'main') {
                return { ...chapter, isCompletedMain: !chapter.isCompletedMain };
              } else {
                return { ...chapter, isCompletedAdvanced: !chapter.isCompletedAdvanced };
              }
            }
            return chapter;
          });
          
          return {
            ...subject,
            chapters: updatedChapters,
            mainProgress: calculateProgress(updatedChapters, 'main'),
            advancedProgress: calculateProgress(updatedChapters, 'advanced')
          };
        }
        return subject;
      })
    );
  }, [setSubjects, calculateProgress]);
  
  const importSyllabus = useCallback((importedSubjects: Subject[]) => {
    setSubjects(importedSubjects);
  }, [setSubjects]);
  
  return {
    subjects,
    addSubject,
    updateSubject,
    deleteSubject,
    addChapter,
    updateChapter,
    deleteChapter,
    toggleChapterCompletion,
    updateSubjectProgress,
    importSyllabus
  };
}
