import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import useLocalStorage from "@/hooks/use-local-storage";
import { DailyGoal } from "@/types";
import { useTasks } from "@/hooks/use-tasks";
import { calculateProgress } from "@/lib/utils";
import { useEffect } from "react";

export function DailyGoals() {
  const { getTodaysTasks } = useTasks();
  const [dailyGoals, setDailyGoals] = useLocalStorage<DailyGoal[]>("study-track-daily-goals", [
    {
      id: "study-hours",
      name: "Study Hours",
      target: 8,
      current: 0,
      unit: "hours"
    },
    {
      id: "tasks-completed",
      name: "Tasks Completed",
      target: 5,
      current: 0,
      unit: "tasks"
    },
    {
      id: "problems-solved",
      name: "Problems Solved",
      target: 20,
      current: 0,
      unit: "problems"
    }
  ]);

  // Update tasks completed goal based on completed tasks
  useEffect(() => {
    // Get today's tasks once when the component mounts
    const todaysTasks = getTodaysTasks();
    const completedTasks = todaysTasks.filter(task => task.isCompleted).length;
    
    // Calculate study hours from completed tasks
    const studyMinutes = todaysTasks
      .filter(task => task.isCompleted && task.actualTimeTaken !== undefined)
      .reduce((total, task) => total + (task.actualTimeTaken || 0), 0);
    
    const studyHours = Math.round(studyMinutes / 60 * 10) / 10; // Round to 1 decimal place
    
    // Update all goals in a single state update to avoid multiple renders
    setDailyGoals(prevGoals =>
      prevGoals.map(goal => {
        if (goal.id === "tasks-completed") {
          return { ...goal, current: completedTasks };
        } else if (goal.id === "study-hours") {
          return { ...goal, current: studyHours };
        }
        return goal;
      })
    );
  }, []); // Empty dependency array so it only runs once on mount

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Goals</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {dailyGoals.map((goal) => (
            <div key={goal.id}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">{goal.name}</span>
                <span className="text-sm font-medium">
                  {goal.current}/{goal.target} {goal.unit}
                </span>
              </div>
              <Progress 
                value={calculateProgress(goal.current, goal.target)} 
                className={`h-2 bg-gray-200 dark:bg-gray-700 ${
                  goal.id === "study-hours" 
                    ? "text-primary" 
                    : goal.id === "tasks-completed" 
                    ? "text-secondary" 
                    : "text-amber-500"
                }`}
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
