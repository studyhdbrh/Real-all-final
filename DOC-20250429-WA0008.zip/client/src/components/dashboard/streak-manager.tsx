import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStreak } from "@/hooks/use-streak";
import { Award } from "lucide-react";
import { cn } from "@/lib/utils";

export function StreakManager() {
  const { streakData } = useStreak();
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Study Streak</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center space-x-4 mb-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">{streakData.currentStreak}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Days</div>
          </div>
          
          <div className="h-10 w-0.5 bg-gray-200 dark:bg-gray-700"></div>
          
          <div className="flex flex-col items-center">
            <div className="flex space-x-1 mb-1">
              {[...Array(Math.min(3, Math.ceil(streakData.bestStreak / 10)))].map((_, i) => (
                <Award key={i} className="h-5 w-5 text-amber-500" />
              ))}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              Best: {streakData.bestStreak} days
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="text-sm font-medium mb-2">Last 2 weeks</div>
          <div className="flex flex-wrap justify-between">
            {streakData.lastTwoWeeks.map((day, index) => (
              <div 
                key={day.date}
                className={cn(
                  "flex items-center justify-center w-9 h-9 rounded-full mb-2 text-xs font-medium",
                  day.status === 'completed' && "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300",
                  day.status === 'holiday' && "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300",
                  day.status === 'missed' && "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300"
                )}
              >
                {index + 1}
              </div>
            ))}
          </div>
        </div>
        
        <div className="flex text-xs text-gray-600 dark:text-gray-400 justify-center space-x-4">
          <div className="flex items-center">
            <span className="w-3 h-3 bg-green-100 dark:bg-green-900 rounded-full mr-1"></span>
            <span>Completed</span>
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 bg-amber-100 dark:bg-amber-900 rounded-full mr-1"></span>
            <span>Holiday</span>
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 bg-red-100 dark:bg-red-900 rounded-full mr-1"></span>
            <span>Missed</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
