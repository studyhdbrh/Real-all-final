import { useState } from "react";
import { PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Task } from "@/types";
import { useTasks } from "@/hooks/use-tasks";
import { formatTime } from "@/lib/utils";
import { TaskCompletionModal } from "./task-completion-modal";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getToday } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";

export function TodaysTasks() {
  const { getTodaysTasks, addTask, markTaskAsComplete } = useTasks();
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [isCompletionModalOpen, setIsCompletionModalOpen] = useState(false);
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  
  const todaysTasks = getTodaysTasks();
  
  const handleTaskCheck = (taskId: string) => {
    setSelectedTaskId(taskId);
    setIsCompletionModalOpen(true);
  };
  
  const handleSaveTaskTime = (hours: number, minutes: number) => {
    if (selectedTaskId) {
      markTaskAsComplete(selectedTaskId, hours * 60 + minutes);
      setIsCompletionModalOpen(false);
      setSelectedTaskId(null);
    }
  };
  
  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Today's Tasks</CardTitle>
          <Button 
            size="sm" 
            className="bg-primary hover:bg-primary/90 text-white"
            onClick={() => setIsAddTaskModalOpen(true)}
          >
            <PlusCircle className="mr-1 h-4 w-4" /> Add Task
          </Button>
        </CardHeader>
        <CardContent>
          {todaysTasks.length === 0 ? (
            <div className="text-center py-6 text-gray-500">
              No tasks for today. Add your first task!
            </div>
          ) : (
            <div className="space-y-3">
              {todaysTasks.map((task) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  onCheck={handleTaskCheck} 
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      <TaskCompletionModal 
        isOpen={isCompletionModalOpen}
        onClose={() => {
          setIsCompletionModalOpen(false);
          setSelectedTaskId(null);
        }}
        onSave={handleSaveTaskTime}
      />
      
      <AddTaskModal 
        isOpen={isAddTaskModalOpen}
        onClose={() => setIsAddTaskModalOpen(false)}
        onAddTask={addTask}
      />
    </>
  );
}

interface TaskCardProps {
  task: Task;
  onCheck: (taskId: string) => void;
}

function TaskCard({ task, onCheck }: TaskCardProps) {
  return (
    <div 
      className={cn(
        "task-card border border-gray-200 dark:border-gray-700 rounded-lg p-3 bg-white dark:bg-darkSurface hover:shadow transition-all duration-200",
        task.isCritical && "border-l-4 border-l-red-500",
        task.isImportant && !task.isCritical && "border-l-4 border-l-yellow-500"
      )}
    >
      <div className="flex items-start">
        <Checkbox 
          className="mt-1" 
          checked={task.isCompleted} 
          onCheckedChange={() => {
            if (!task.isCompleted) {
              onCheck(task.id);
            }
          }}
          disabled={task.isCompleted}
        />
        <div className="ml-3 flex-1">
          <div className="flex justify-between">
            <h4 className="text-base font-medium">{task.title}</h4>
            <span className="text-xs text-gray-500 dark:text-gray-400">
              {formatTime(task.startTime)} - {formatTime(task.endTime)}
            </span>
          </div>
          {task.description && (
            <div className="mt-1 text-sm text-gray-600 dark:text-gray-400">
              {task.description}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTask: (task: Omit<Task, 'id'>) => void;
}

function AddTaskModal({ isOpen, onClose, onAddTask }: AddTaskModalProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("10:00");
  const [isImportant, setIsImportant] = useState(false);
  const [isCritical, setIsCritical] = useState(false);
  
  const handleSubmit = () => {
    if (!title) return;
    
    onAddTask({
      title,
      description,
      startTime,
      endTime,
      date: getToday(),
      isCompleted: false,
      isImportant,
      isCritical
    });
    
    // Reset form
    setTitle("");
    setDescription("");
    setStartTime("09:00");
    setEndTime("10:00");
    setIsImportant(false);
    setIsCritical(false);
    
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Task</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="title">Task Title</Label>
            <Input 
              id="title" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)} 
              placeholder="e.g. Physics - Mechanics Revision"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea 
              id="description" 
              value={description} 
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Complete all formulas and solve 10 problems" 
              rows={2}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startTime">Start Time</Label>
              <Input 
                id="startTime" 
                type="time" 
                value={startTime} 
                onChange={(e) => setStartTime(e.target.value)} 
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="endTime">End Time</Label>
              <Input 
                id="endTime" 
                type="time" 
                value={endTime} 
                onChange={(e) => setEndTime(e.target.value)} 
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="important"
                checked={isImportant}
                onCheckedChange={setIsImportant}
              />
              <Label htmlFor="important">Important</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="critical"
                checked={isCritical}
                onCheckedChange={setIsCritical}
              />
              <Label htmlFor="critical">Critical</Label>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!title}>
            Add Task
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
