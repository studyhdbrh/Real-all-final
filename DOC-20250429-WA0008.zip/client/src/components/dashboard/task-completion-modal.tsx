import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface TaskCompletionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (hours: number, minutes: number) => void;
}

export function TaskCompletionModal({
  isOpen,
  onClose,
  onSave
}: TaskCompletionModalProps) {
  const [hours, setHours] = useState<number>(0);
  const [minutes, setMinutes] = useState<number>(0);

  const handleSave = () => {
    onSave(hours, minutes);
    setHours(0);
    setMinutes(0);
  };

  const handleCancel = () => {
    onClose();
    setHours(0);
    setMinutes(0);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Task Completed</DialogTitle>
          <DialogDescription>
            How much time did this task actually take?
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex items-center space-x-3 my-4">
          <div className="flex items-center space-x-2">
            <Input
              type="number"
              value={hours}
              onChange={(e) => setHours(parseInt(e.target.value) || 0)}
              min={0}
              max={24}
              className="w-20 text-center"
            />
            <Label>hours</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Input
              type="number"
              value={minutes}
              onChange={(e) => setMinutes(parseInt(e.target.value) || 0)}
              min={0}
              max={59}
              className="w-20 text-center"
            />
            <Label>minutes</Label>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
