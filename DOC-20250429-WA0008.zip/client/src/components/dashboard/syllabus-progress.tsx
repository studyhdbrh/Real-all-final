import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useSyllabus } from "@/hooks/use-syllabus";
import { Progress } from "@/components/ui/progress";

export function SyllabusProgress() {
  const { subjects } = useSyllabus();

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Syllabus Progress</CardTitle>
        <div className="text-sm">
          <span className="inline-block w-3 h-3 rounded-full bg-primary mr-1"></span>
          <span className="mr-3">Main</span>
          <span className="inline-block w-3 h-3 rounded-full bg-secondary mr-1"></span>
          <span>Advanced</span>
        </div>
      </CardHeader>
      <CardContent>
        {subjects.length === 0 ? (
          <div className="text-center py-6 text-gray-500">
            No subjects added yet. Add subjects in the Syllabus Tracker.
          </div>
        ) : (
          <div className="space-y-4">
            {subjects.map((subject) => (
              <div key={subject.id} className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">{subject.name}</span>
                  <span className="text-sm">{subject.mainProgress}% complete</span>
                </div>
                <Progress value={subject.mainProgress} className="h-2 bg-gray-200 dark:bg-gray-700" indicatorClassName="bg-primary" />
                <Progress value={subject.advancedProgress} className="h-2 bg-gray-200 dark:bg-gray-700" indicatorClassName="bg-secondary" />
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
