import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { usePomodoro } from "@/hooks/use-pomodoro";
import { formatTimeFromSeconds } from "@/lib/utils";
import { Pause, Play, RefreshCw } from "lucide-react";

export function PomodoroTimer() {
  const { state, start, pause, resume, reset } = usePomodoro();
  
  // Calculate the percentage for the circle progress
  const percentage = (state.timeLeft / (state.isBreak ? state.totalCycles * 60 : state.totalCycles * 60)) * 100;
  const circleDashOffset = 283 - (283 * percentage) / 100;
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Pomodoro Timer</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center">
          <div className="relative mb-4 w-40 h-40">
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="#e2e8f0" strokeWidth="8" />
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                fill="none" 
                stroke={state.isBreak ? "#1cc88a" : "#4e73df"} 
                strokeWidth="8" 
                strokeDasharray="283" 
                strokeDashoffset={circleDashOffset}
                transform="rotate(-90 50 50)" 
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-3xl font-bold">{formatTimeFromSeconds(state.timeLeft)}</div>
            </div>
          </div>
          
          <div className="text-sm mb-4">
            <span className="font-medium">{state.isBreak ? "Break Time" : "Focus Time"}</span> - <span>Cycle {state.currentCycle}/{state.totalCycles}</span>
          </div>
          
          <div className="flex space-x-2">
            {!state.isActive ? (
              <Button 
                className="bg-primary hover:bg-primary/90 text-white" 
                onClick={start}
              >
                <Play className="mr-1 h-4 w-4" /> Start
              </Button>
            ) : state.isPaused ? (
              <Button 
                className="bg-primary hover:bg-primary/90 text-white" 
                onClick={resume}
              >
                <Play className="mr-1 h-4 w-4" /> Resume
              </Button>
            ) : (
              <Button 
                className="bg-primary hover:bg-primary/90 text-white" 
                onClick={pause}
              >
                <Pause className="mr-1 h-4 w-4" /> Pause
              </Button>
            )}
            <Button 
              variant="outline" 
              onClick={reset}
            >
              <RefreshCw className="mr-1 h-4 w-4" /> Reset
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
