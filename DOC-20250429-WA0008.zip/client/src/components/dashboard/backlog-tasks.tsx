import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTasks } from "@/hooks/use-tasks";
import { formatDate } from "@/lib/utils";
import { PlusCircle } from "lucide-react";
import { Link } from "wouter";

export function BacklogTasks() {
  const { getBacklogTasks, moveTaskToToday } = useTasks();
  
  const backlogTasks = getBacklogTasks().slice(0, 3); // Only show up to 3 tasks
  const totalBacklog = getBacklogTasks().length;
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Backlog Tasks</CardTitle>
        <Link href="/backlog">
          <div className="text-primary hover:text-primary/90 text-sm cursor-pointer">View all</div>
        </Link>
      </CardHeader>
      <CardContent>
        {backlogTasks.length === 0 ? (
          <div className="text-center py-6 text-gray-500">
            No pending tasks in your backlog.
          </div>
        ) : (
          <div className="space-y-3">
            {backlogTasks.map((task) => (
              <div key={task.id} className="flex items-center p-2 border border-gray-200 dark:border-gray-700 rounded">
                <div className="flex-1">
                  <div className="text-sm font-medium">{task.title}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    Pending from {formatDate(task.date)}
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="text-primary hover:text-primary/90"
                  onClick={() => moveTaskToToday(task.id)}
                >
                  <PlusCircle className="h-5 w-5" />
                  <span className="sr-only">Add to today</span>
                </Button>
              </div>
            ))}
            
            {totalBacklog > 3 && (
              <div className="text-center text-sm text-gray-500 pt-2">
                +{totalBacklog - 3} more tasks in your backlog
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
