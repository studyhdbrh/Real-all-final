import { PlusCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTests } from "@/hooks/use-tests";
import { formatDate } from "@/lib/utils";
import { ArrowDownIcon, ArrowUpIcon } from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getToday } from "@/lib/utils";

export function RecentTestMarks() {
  const { getRecentTests, addTest } = useTests();
  const [isAddTestModalOpen, setIsAddTestModalOpen] = useState(false);
  
  const recentTests = getRecentTests(5);

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Test Scores</CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-primary hover:text-primary/90"
            onClick={() => setIsAddTestModalOpen(true)}
          >
            <PlusCircle className="mr-1 h-4 w-4" /> Add New Test
          </Button>
        </CardHeader>
        <CardContent>
          {recentTests.length === 0 ? (
            <div className="text-center py-6 text-gray-500">
              No test scores added yet. Add your first test result!
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-800">
                  <tr>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Subject
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Topic
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Score
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Change
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-darkSurface divide-y divide-gray-200 dark:divide-gray-700">
                  {recentTests.map((test) => (
                    <tr key={test.id}>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        {formatDate(test.date)}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-white">
                        {test.subject}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        {test.topic}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        {test.score}/{test.maxScore}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm">
                        {test.change > 0 ? (
                          <span className="text-secondary flex items-center">
                            <ArrowUpIcon className="h-3 w-3 mr-1" /> +{test.change}
                          </span>
                        ) : test.change < 0 ? (
                          <span className="text-red-500 flex items-center">
                            <ArrowDownIcon className="h-3 w-3 mr-1" /> {test.change}
                          </span>
                        ) : (
                          <span className="text-gray-500">0</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      
      <AddTestModal 
        isOpen={isAddTestModalOpen}
        onClose={() => setIsAddTestModalOpen(false)}
        onAddTest={addTest}
      />
    </>
  );
}

interface AddTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTest: (test: any) => void;
}

function AddTestModal({ isOpen, onClose, onAddTest }: AddTestModalProps) {
  const [subject, setSubject] = useState("");
  const [topic, setTopic] = useState("");
  const [score, setScore] = useState<number>(0);
  const [maxScore, setMaxScore] = useState<number>(60);
  const [date, setDate] = useState(getToday());
  
  const handleSubmit = () => {
    if (!subject || !topic) return;
    
    onAddTest({
      subject,
      topic,
      score,
      maxScore,
      date
    });
    
    // Reset form
    setSubject("");
    setTopic("");
    setScore(0);
    setMaxScore(60);
    setDate(getToday());
    
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Test</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger>
                <SelectValue placeholder="Select subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Physics">Physics</SelectItem>
                <SelectItem value="Chemistry">Chemistry</SelectItem>
                <SelectItem value="Mathematics">Mathematics</SelectItem>
                <SelectItem value="Biology">Biology</SelectItem>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="Social Studies">Social Studies</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="topic">Topic</Label>
            <Input 
              id="topic" 
              value={topic} 
              onChange={(e) => setTopic(e.target.value)} 
              placeholder="e.g. Electrostatics"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="score">Your Score</Label>
              <Input 
                id="score" 
                type="number" 
                min={0}
                max={maxScore}
                value={score} 
                onChange={(e) => setScore(Number(e.target.value))} 
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="maxScore">Maximum Score</Label>
              <Input 
                id="maxScore" 
                type="number" 
                min={1}
                value={maxScore} 
                onChange={(e) => setMaxScore(Number(e.target.value))} 
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="date">Test Date</Label>
            <Input 
              id="date" 
              type="date" 
              value={date} 
              max={getToday()}
              onChange={(e) => setDate(e.target.value)} 
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!subject || !topic}>
            Add Test
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
