import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useTasks } from "@/hooks/use-tasks";
import { useStreak } from "@/hooks/use-streak";
import { useSyllabus } from "@/hooks/use-syllabus";
import { useTests } from "@/hooks/use-tests";
import { Award, Lock, Check, Star, Clock, BarChart2, BookOpen, PenTool, LightbulbIcon, Target, Zap } from "lucide-react";
import { formatDate } from "@/lib/utils";
import useLocalStorage from "@/hooks/use-local-storage";
import { Achievement } from "@/types";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";

export function AchievementsList() {
  const { tasks } = useTasks();
  const { streakData } = useStreak();
  const { subjects } = useSyllabus();
  const { tests } = useTests();
  
  const [achievements, setAchievements] = useLocalStorage<Achievement[]>("study-track-achievements", []);
  
  // Default achievements to check
  const defaultAchievements: Omit<Achievement, "isUnlocked" | "unlockedDate">[] = [
    {
      id: "streak-5",
      title: "Streak Beginner",
      description: "Maintain a 5-day study streak",
      icon: "fire"
    },
    {
      id: "streak-10",
      title: "Streak Intermediate",
      description: "Maintain a 10-day study streak",
      icon: "fire"
    },
    {
      id: "streak-30",
      title: "Streak Master",
      description: "Maintain a 30-day study streak",
      icon: "fire"
    },
    {
      id: "tasks-10",
      title: "Task Starter",
      description: "Complete 10 tasks",
      icon: "check"
    },
    {
      id: "tasks-50",
      title: "Task Warrior",
      description: "Complete 50 tasks",
      icon: "check"
    },
    {
      id: "tasks-100",
      title: "Task Master",
      description: "Complete 100 tasks",
      icon: "check"
    },
    {
      id: "day-5-tasks",
      title: "Productivity Day",
      description: "Complete 5 tasks in a single day",
      icon: "zap"
    },
    {
      id: "day-10-tasks",
      title: "Super Productive Day",
      description: "Complete 10 tasks in a single day",
      icon: "zap"
    },
    {
      id: "subject-50",
      title: "Subject Explorer",
      description: "Reach 50% completion in any subject",
      icon: "book"
    },
    {
      id: "subject-100",
      title: "Subject Master",
      description: "Complete 100% of a subject",
      icon: "book"
    },
    {
      id: "subjects-3",
      title: "Curriculum Manager",
      description: "Add at least 3 subjects to track",
      icon: "book"
    },
    {
      id: "tests-5",
      title: "Test Taker",
      description: "Record 5 test scores",
      icon: "pen"
    },
    {
      id: "tests-10",
      title: "Test Tracker",
      description: "Record 10 test scores",
      icon: "pen"
    },
    {
      id: "score-50",
      title: "Good Score",
      description: "Score at least 50 out of 60 in any test",
      icon: "star"
    },
    {
      id: "score-55",
      title: "Great Score",
      description: "Score at least 55 out of 60 in any test",
      icon: "star"
    },
    {
      id: "score-60",
      title: "Perfect Score",
      description: "Score 60 out of 60 in any test",
      icon: "star"
    }
  ];
  
  // Initialize achievements if not already set
  useEffect(() => {
    if (achievements.length === 0) {
      setAchievements(
        defaultAchievements.map(achievement => ({
          ...achievement,
          isUnlocked: false
        }))
      );
    }
  }, [achievements, setAchievements]);
  
  // Check for achievements
  useEffect(() => {
    const completedTasks = tasks.filter(task => task.isCompleted);
    const newAchievements = [...achievements];
    let changed = false;
    
    // Streak achievements
    if (streakData.bestStreak >= 5) {
      const achievement = newAchievements.find(a => a.id === "streak-5");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (streakData.bestStreak >= 10) {
      const achievement = newAchievements.find(a => a.id === "streak-10");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (streakData.bestStreak >= 30) {
      const achievement = newAchievements.find(a => a.id === "streak-30");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    // Task achievements
    if (completedTasks.length >= 10) {
      const achievement = newAchievements.find(a => a.id === "tasks-10");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (completedTasks.length >= 50) {
      const achievement = newAchievements.find(a => a.id === "tasks-50");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (completedTasks.length >= 100) {
      const achievement = newAchievements.find(a => a.id === "tasks-100");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    // Count tasks per day
    const tasksPerDay = new Map<string, number>();
    completedTasks.forEach(task => {
      const count = tasksPerDay.get(task.date) || 0;
      tasksPerDay.set(task.date, count + 1);
    });
    
    // Check for max tasks in a day
    const maxTasksInDay = Math.max(...Array.from(tasksPerDay.values()), 0);
    
    if (maxTasksInDay >= 5) {
      const achievement = newAchievements.find(a => a.id === "day-5-tasks");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (maxTasksInDay >= 10) {
      const achievement = newAchievements.find(a => a.id === "day-10-tasks");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    // Subject achievements
    const maxProgress = Math.max(...subjects.map(subject => subject.mainProgress), 0);
    
    if (maxProgress >= 50) {
      const achievement = newAchievements.find(a => a.id === "subject-50");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (maxProgress >= 100) {
      const achievement = newAchievements.find(a => a.id === "subject-100");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (subjects.length >= 3) {
      const achievement = newAchievements.find(a => a.id === "subjects-3");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    // Test achievements
    if (tests.length >= 5) {
      const achievement = newAchievements.find(a => a.id === "tests-5");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (tests.length >= 10) {
      const achievement = newAchievements.find(a => a.id === "tests-10");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    // Test score achievements
    const maxScore = Math.max(...tests.map(test => test.score), 0);
    
    if (maxScore >= 50) {
      const achievement = newAchievements.find(a => a.id === "score-50");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (maxScore >= 55) {
      const achievement = newAchievements.find(a => a.id === "score-55");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (maxScore >= 60) {
      const achievement = newAchievements.find(a => a.id === "score-60");
      if (achievement && !achievement.isUnlocked) {
        achievement.isUnlocked = true;
        achievement.unlockedDate = new Date().toISOString();
        changed = true;
      }
    }
    
    if (changed) {
      setAchievements(newAchievements);
    }
  }, [tasks, streakData, subjects, tests, achievements, setAchievements]);
  
  // Group achievements by category
  const streakAchievements = achievements.filter(a => a.id.startsWith("streak-"));
  const taskAchievements = achievements.filter(a => a.id.startsWith("tasks-") || a.id.startsWith("day-"));
  const subjectAchievements = achievements.filter(a => a.id.startsWith("subject-") || a.id.startsWith("subjects-"));
  const testAchievements = achievements.filter(a => a.id.startsWith("tests-") || a.id.startsWith("score-"));
  
  // Calculate total progress
  const unlockedAchievements = achievements.filter(a => a.isUnlocked).length;
  const totalProgress = Math.round((unlockedAchievements / achievements.length) * 100);
  
  return (
    <>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-semibold">Achievements</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Track your progress and earn badges for your accomplishments
          </p>
        </div>
        
        <Card className="w-full md:w-auto mt-4 md:mt-0">
          <CardContent className="p-4 flex items-center space-x-4">
            <div className="flex-shrink-0">
              <Award className="h-10 w-10 text-primary" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium mb-1">Achievement Progress</div>
              <Progress value={totalProgress} />
              <div className="text-sm text-muted-foreground mt-1">
                {unlockedAchievements} / {achievements.length} achievements unlocked
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <AchievementCategory
          title="Streak Achievements"
          description="Rewards for maintaining daily study streaks"
          icon={<Zap className="h-5 w-5" />}
          achievements={streakAchievements}
        />
        
        <AchievementCategory
          title="Task Achievements"
          description="Rewards for completing study tasks"
          icon={<Check className="h-5 w-5" />}
          achievements={taskAchievements}
        />
        
        <AchievementCategory
          title="Subject Achievements"
          description="Rewards for syllabus progress"
          icon={<BookOpen className="h-5 w-5" />}
          achievements={subjectAchievements}
        />
        
        <AchievementCategory
          title="Test Achievements"
          description="Rewards for test performance"
          icon={<PenTool className="h-5 w-5" />}
          achievements={testAchievements}
        />
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent Unlocks</CardTitle>
          <CardDescription>Your most recently unlocked achievements</CardDescription>
        </CardHeader>
        <CardContent>
          {unlockedAchievements === 0 ? (
            <div className="text-center py-6 text-gray-500">
              <Lock className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>No achievements unlocked yet. Keep studying to earn badges!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {achievements
                .filter(a => a.isUnlocked)
                .sort((a, b) => 
                  new Date(b.unlockedDate!).getTime() - new Date(a.unlockedDate!).getTime()
                )
                .slice(0, 5)
                .map(achievement => (
                  <div key={achievement.id} className="flex items-center space-x-4 p-3 border rounded-lg">
                    <AchievementIcon icon={achievement.icon} className="h-10 w-10 text-primary" />
                    <div className="flex-1">
                      <div className="font-medium">{achievement.title}</div>
                      <div className="text-sm text-muted-foreground">{achievement.description}</div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatDate(achievement.unlockedDate!)}
                    </div>
                  </div>
                ))
              }
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}

interface AchievementCategoryProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  achievements: Achievement[];
}

function AchievementCategory({ title, description, icon, achievements }: AchievementCategoryProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-2">
          <div className="bg-primary/10 p-2 rounded-full">{icon}</div>
          <div>
            <CardTitle>{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-60">
          <div className="space-y-4">
            {achievements.map(achievement => (
              <div 
                key={achievement.id} 
                className={`flex items-start space-x-3 p-3 rounded-lg border ${
                  achievement.isUnlocked ? 'bg-primary/5' : 'opacity-70'
                }`}
              >
                <div className={`rounded-full p-2 ${
                  achievement.isUnlocked ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'
                }`}>
                  <AchievementIcon icon={achievement.icon} />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium">{achievement.title}</h4>
                    {achievement.isUnlocked ? (
                      <Badge variant="success" className="text-[10px]">Unlocked</Badge>
                    ) : (
                      <Badge variant="outline" className="text-[10px]">Locked</Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{achievement.description}</p>
                  {achievement.isUnlocked && achievement.unlockedDate && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Unlocked on {formatDate(achievement.unlockedDate)}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function AchievementIcon({ icon, className = "h-5 w-5" }: { icon: string, className?: string }) {
  switch (icon) {
    case "fire":
      return <Zap className={className} />;
    case "check":
      return <Check className={className} />;
    case "book":
      return <BookOpen className={className} />;
    case "pen":
      return <PenTool className={className} />;
    case "star":
      return <Star className={className} />;
    case "zap":
      return <LightbulbIcon className={className} />;
    default:
      return <Award className={className} />;
  }
}
