import { useState } from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getMonth, getYear } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { useHolidays } from "@/hooks/use-holidays";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { getToday } from "@/lib/utils";
import { CalendarIcon, Info } from "lucide-react";

export function HolidayManager() {
  const { holidays, addHoliday, deleteHoliday, getHolidaysByMonth, isHolidayAvailable } = useHolidays();
  const [isAddHolidayModalOpen, setIsAddHolidayModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [holidayDetails, setHolidayDetails] = useState({
    reason: "",
    isFullDay: true,
    hours: 4
  });
  
  const currentMonth = selectedDate ? getMonth(selectedDate) + 1 : getMonth(new Date()) + 1;
  const currentYear = selectedDate ? getYear(selectedDate) : getYear(new Date());
  
  const holidaysInMonth = getHolidaysByMonth(currentYear, currentMonth);
  const canAddHoliday = isHolidayAvailable(currentYear, currentMonth);
  
  const handleAddHoliday = () => {
    if (!selectedDate || !holidayDetails.reason) return;
    
    addHoliday({
      date: format(selectedDate, 'yyyy-MM-dd'),
      reason: holidayDetails.reason,
      isFullDay: holidayDetails.isFullDay,
      hours: holidayDetails.hours
    });
    
    // Reset form
    setHolidayDetails({
      reason: "",
      isFullDay: true,
      hours: 4
    });
    
    setIsAddHolidayModalOpen(false);
  };
  
  // Function to determine if a date has a holiday
  const dateHasHoliday = (date: Date) => {
    const formattedDate = format(date, 'yyyy-MM-dd');
    return holidays.some(holiday => holiday.date === formattedDate);
  };
  
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Holiday Calendar</CardTitle>
            <CardDescription>
              You've used {holidaysInMonth.length} out of 7 holidays this month
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              className="rounded-md border"
              modifiers={{
                holiday: (date) => dateHasHoliday(date),
              }}
              modifiersStyles={{
                holiday: { backgroundColor: 'rgba(246, 194, 62, 0.2)', color: '#f6c23e', fontWeight: 'bold' }
              }}
            />
            
            <div className="mt-6 flex justify-end">
              <Button 
                onClick={() => setIsAddHolidayModalOpen(true)}
                disabled={!canAddHoliday || !selectedDate || format(selectedDate, 'yyyy-MM-dd') < getToday()}
              >
                Request Holiday
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Holiday Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Badge className="bg-amber-400 hover:bg-amber-400">{holidaysInMonth.length}</Badge>
                <span>Holidays taken this month</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Badge variant="outline">{7 - holidaysInMonth.length}</Badge>
                <span>Holidays remaining</span>
              </div>
              
              {!canAddHoliday && (
                <div className="flex items-center text-red-500 text-sm mt-2">
                  <Info className="h-4 w-4 mr-1" />
                  <span>Maximum holiday limit reached for this month</span>
                </div>
              )}
              
              <div className="border-t pt-4 mt-4">
                <h3 className="font-medium mb-2">Recent Holidays</h3>
                {holidaysInMonth.length === 0 ? (
                  <p className="text-sm text-gray-500">No holidays taken this month</p>
                ) : (
                  <ul className="space-y-2">
                    {holidaysInMonth.map(holiday => (
                      <li key={holiday.id} className="text-sm border border-gray-200 dark:border-gray-700 rounded p-2">
                        <div className="flex justify-between">
                          <span className="font-medium">{format(new Date(holiday.date), 'MMM dd, yyyy')}</span>
                          <span>
                            {holiday.isFullDay ? 'Full day' : `${holiday.hours} hours`}
                          </span>
                        </div>
                        <p className="text-gray-600 dark:text-gray-400">{holiday.reason}</p>
                        <div className="mt-1 text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-500 hover:text-red-600 h-auto py-1 px-2"
                            onClick={() => deleteHoliday(holiday.id)}
                          >
                            Cancel
                          </Button>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Dialog open={isAddHolidayModalOpen} onOpenChange={setIsAddHolidayModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request Holiday</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="flex items-center space-x-2">
              <CalendarIcon className="h-5 w-5 text-gray-500" />
              <span className="font-medium">
                {selectedDate ? format(selectedDate, 'MMMM dd, yyyy') : 'Select a date'}
              </span>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="reason">Reason for Holiday</Label>
              <Textarea 
                id="reason" 
                value={holidayDetails.reason} 
                onChange={(e) => setHolidayDetails({...holidayDetails, reason: e.target.value})}
                placeholder="E.g., Family function, Health reasons, etc." 
                rows={3}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="fullDay"
                checked={holidayDetails.isFullDay}
                onCheckedChange={(checked) => setHolidayDetails({...holidayDetails, isFullDay: checked})}
              />
              <Label htmlFor="fullDay">Full Day Holiday</Label>
            </div>
            
            {!holidayDetails.isFullDay && (
              <div className="space-y-2">
                <Label htmlFor="hours">Hours Needed</Label>
                <Input 
                  id="hours" 
                  type="number" 
                  min={1}
                  max={12}
                  value={holidayDetails.hours} 
                  onChange={(e) => setHolidayDetails({...holidayDetails, hours: parseInt(e.target.value) || 1})} 
                />
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddHolidayModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddHoliday}
              disabled={!holidayDetails.reason}
            >
              Confirm Holiday
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
