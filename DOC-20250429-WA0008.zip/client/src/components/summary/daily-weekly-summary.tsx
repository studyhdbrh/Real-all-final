import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useTasks } from "@/hooks/use-tasks";
import { useStreak } from "@/hooks/use-streak";
import { useSyllabus } from "@/hooks/use-syllabus";
import { Badge } from "@/components/ui/badge";
import { Calendar, ChevronLeft, ChevronRight, Clock, CheckCircle, Award } from "lucide-react";
import { format, parseISO, startOfWeek, endOfWeek, addWeeks, subWeeks, isWithinInterval } from "date-fns";
import { DailySummary, WeeklySummary } from "@/types";
import useLocalStorage from "@/hooks/use-local-storage";
import { getToday, getDateRangeForWeek } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";

export function DailyWeeklySummary() {
  const { tasks } = useTasks();
  const { streakData } = useStreak();
  const { subjects } = useSyllabus();
  
  const [summaries, setSummaries] = useLocalStorage<{
    daily: DailySummary[];
    weekly: WeeklySummary[];
  }>("study-track-summaries", { daily: [], weekly: [] });
  
  const [currentDate, setCurrentDate] = useState(new Date());
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  
  // Generate or update summaries when component mounts or data changes
  useEffect(() => {
    generateDailySummary(getToday());
    
    const [weekStartDate, weekEndDate] = getDateRangeForWeek(new Date());
    generateWeeklySummary(weekStartDate, weekEndDate);
  }, [tasks, streakData, subjects]);
  
  const generateDailySummary = (date: string) => {
    // Check if summary already exists for this date
    const existingSummary = summaries.daily.find(summary => summary.date === date);
    if (existingSummary) return;
    
    const dayTasks = tasks.filter(task => task.date === date);
    const completedTasks = dayTasks.filter(task => task.isCompleted);
    
    const totalStudyMinutes = completedTasks.reduce((total, task) => {
      return total + (task.actualTimeTaken || 0);
    }, 0);
    
    // Get achievements for the day (this is simplified, in a real app you'd track actual achievements)
    const achievements: string[] = [];
    
    if (completedTasks.length >= 5) {
      achievements.push("Completed 5+ tasks");
    }
    
    if (totalStudyMinutes >= 240) { // 4 hours
      achievements.push("Studied 4+ hours");
    }
    
    const streakDay = streakData.lastTwoWeeks.find(day => day.date === date);
    if (streakDay && streakDay.status === 'completed') {
      achievements.push("Maintained streak");
    }
    
    const newSummary: DailySummary = {
      date,
      tasksCompleted: completedTasks.length,
      totalTasks: dayTasks.length,
      studyHours: Math.round(totalStudyMinutes / 60 * 10) / 10, // Round to 1 decimal
      achievements
    };
    
    setSummaries(prev => ({
      ...prev,
      daily: [...prev.daily, newSummary]
    }));
  };
  
  const generateWeeklySummary = (weekStartDate: string, weekEndDate: string) => {
    // Check if summary already exists for this week
    const existingSummary = summaries.weekly.find(
      summary => summary.weekStartDate === weekStartDate && summary.weekEndDate === weekEndDate
    );
    if (existingSummary) return;
    
    const weekTasks = tasks.filter(task => {
      return task.date >= weekStartDate && task.date <= weekEndDate;
    });
    
    const completedTasks = weekTasks.filter(task => task.isCompleted);
    
    const totalStudyMinutes = completedTasks.reduce((total, task) => {
      return total + (task.actualTimeTaken || 0);
    }, 0);
    
    // Check if streak was maintained throughout the week
    const streakMaintained = true; // Simplified; in reality, check each day in the week
    
    // Get achievements for the week
    const achievements: string[] = [];
    
    if (completedTasks.length >= 20) {
      achievements.push("Completed 20+ tasks");
    }
    
    if (totalStudyMinutes >= 1200) { // 20 hours
      achievements.push("Studied 20+ hours");
    }
    
    if (streakMaintained) {
      achievements.push("Maintained full week streak");
    }
    
    const newSummary: WeeklySummary = {
      weekStartDate,
      weekEndDate,
      tasksCompleted: completedTasks.length,
      totalTasks: weekTasks.length,
      studyHours: Math.round(totalStudyMinutes / 60 * 10) / 10, // Round to 1 decimal
      achievements,
      streakMaintained
    };
    
    setSummaries(prev => ({
      ...prev,
      weekly: [...prev.weekly, newSummary]
    }));
  };

  // Get current summaries
  const currentDaySummary = summaries.daily.find(
    summary => summary.date === format(currentDate, 'yyyy-MM-dd')
  ) || {
    date: format(currentDate, 'yyyy-MM-dd'),
    tasksCompleted: 0,
    totalTasks: 0,
    studyHours: 0,
    achievements: []
  };
  
  const [weekStartStr, weekEndStr] = [
    format(currentWeekStart, 'yyyy-MM-dd'),
    format(endOfWeek(currentWeekStart, { weekStartsOn: 1 }), 'yyyy-MM-dd')
  ];
  
  const currentWeekSummary = summaries.weekly.find(
    summary => summary.weekStartDate === weekStartStr && summary.weekEndDate === weekEndStr
  ) || {
    weekStartDate: weekStartStr,
    weekEndDate: weekEndStr,
    tasksCompleted: 0,
    totalTasks: 0,
    studyHours: 0,
    achievements: [],
    streakMaintained: false
  };
  
  // Navigation functions
  const goToPreviousDay = () => {
    const prevDate = new Date(currentDate);
    prevDate.setDate(prevDate.getDate() - 1);
    setCurrentDate(prevDate);
  };
  
  const goToNextDay = () => {
    const nextDate = new Date(currentDate);
    nextDate.setDate(nextDate.getDate() + 1);
    if (nextDate <= new Date()) { // Don't allow future dates
      setCurrentDate(nextDate);
    }
  };
  
  const goToPreviousWeek = () => {
    setCurrentWeekStart(subWeeks(currentWeekStart, 1));
  };
  
  const goToNextWeek = () => {
    const nextWeekStart = addWeeks(currentWeekStart, 1);
    if (nextWeekStart <= new Date()) { // Don't allow future weeks
      setCurrentWeekStart(nextWeekStart);
    }
  };
  
  // Prepare data for charts
  const dailyActivityData = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(currentWeekStart);
    date.setDate(date.getDate() + i);
    const dateStr = format(date, 'yyyy-MM-dd');
    const daySummary = summaries.daily.find(s => s.date === dateStr);
    
    return {
      day: format(date, 'EEE'),
      hours: daySummary?.studyHours || 0,
      tasks: daySummary?.tasksCompleted || 0
    };
  });
  
  const subjectProgressData = subjects.map(subject => ({
    name: subject.name,
    progress: subject.mainProgress
  }));
  
  const COLORS = ['#4e73df', '#1cc88a', '#f6c23e', '#e74a3b', '#36b9cc'];

  return (
    <div>
      <Tabs defaultValue="daily">
        <TabsList className="mb-6">
          <TabsTrigger value="daily">Daily Summary</TabsTrigger>
          <TabsTrigger value="weekly">Weekly Summary</TabsTrigger>
        </TabsList>
        
        <TabsContent value="daily">
          <div className="flex justify-between items-center mb-4">
            <Button variant="outline" size="sm" onClick={goToPreviousDay}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <h2 className="text-xl font-semibold">
              {format(currentDate, 'MMMM d, yyyy')}
              {isWithinInterval(currentDate, {
                start: parseISO(getToday()),
                end: parseISO(getToday())
              }) && " (Today)"}
            </h2>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={goToNextDay}
              disabled={format(currentDate, 'yyyy-MM-dd') === getToday()}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Study Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentDaySummary.studyHours} hours</div>
                <p className="text-xs text-muted-foreground">
                  {currentDaySummary.studyHours >= 4 
                    ? "Great productivity!" 
                    : currentDaySummary.studyHours > 0 
                      ? "Keep going!" 
                      : "No study time recorded"}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Tasks Completed</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {currentDaySummary.tasksCompleted}/{currentDaySummary.totalTasks}
                </div>
                <Progress 
                  value={currentDaySummary.totalTasks ? (currentDaySummary.tasksCompleted / currentDaySummary.totalTasks) * 100 : 0} 
                  className="h-2 mt-2"
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                {currentDaySummary.achievements.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No achievements yet</div>
                ) : (
                  <div className="space-y-2">
                    {currentDaySummary.achievements.map((achievement, i) => (
                      <div key={i} className="flex items-center">
                        <Award className="h-4 w-4 text-amber-500 mr-2" />
                        <span className="text-sm">{achievement}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Task Completion</CardTitle>
                <CardDescription>
                  Tasks completed for the day
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                {currentDaySummary.tasksCompleted === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mb-4 opacity-20" />
                    <p>No tasks completed on this day</p>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Completed', value: currentDaySummary.tasksCompleted },
                          { name: 'Pending', value: currentDaySummary.totalTasks - currentDaySummary.tasksCompleted }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        <Cell fill="#1cc88a" />
                        <Cell fill="#e2e8f0" />
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Daily Activity</CardTitle>
                <CardDescription>
                  Task completion over the week
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyActivityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="tasks" name="Tasks Completed" fill="#4e73df" />
                    <Bar dataKey="hours" name="Study Hours" fill="#1cc88a" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="weekly">
          <div className="flex justify-between items-center mb-4">
            <Button variant="outline" size="sm" onClick={goToPreviousWeek}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <h2 className="text-xl font-semibold">
              {format(currentWeekStart, 'MMM d')} - {format(endOfWeek(currentWeekStart, { weekStartsOn: 1 }), 'MMM d, yyyy')}
            </h2>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={goToNextWeek}
              disabled={startOfWeek(new Date(), { weekStartsOn: 1 }).getTime() === currentWeekStart.getTime()}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Weekly Study Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentWeekSummary.studyHours} hours</div>
                <p className="text-xs text-muted-foreground">
                  {currentWeekSummary.studyHours >= 20 
                    ? "Excellent week!" 
                    : currentWeekSummary.studyHours > 10 
                      ? "Good progress!" 
                      : "Try to study more next week"}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Weekly Tasks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {currentWeekSummary.tasksCompleted}/{currentWeekSummary.totalTasks}
                </div>
                <Progress 
                  value={currentWeekSummary.totalTasks ? (currentWeekSummary.tasksCompleted / currentWeekSummary.totalTasks) * 100 : 0} 
                  className="h-2 mt-2"
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Streak Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  {currentWeekSummary.streakMaintained ? (
                    <>
                      <Badge className="bg-green-500">Maintained</Badge>
                      <span className="ml-2 text-sm">Streak kept all week!</span>
                    </>
                  ) : (
                    <>
                      <Badge variant="outline">Broken</Badge>
                      <span className="ml-2 text-sm">Streak broken this week</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Progress</CardTitle>
                <CardDescription>
                  Study hours by day of the week
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={dailyActivityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="hours" name="Study Hours" stroke="#4e73df" />
                    <Line type="monotone" dataKey="tasks" name="Tasks Completed" stroke="#1cc88a" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Subject Progress</CardTitle>
                <CardDescription>
                  Syllabus completion by subject
                </CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                {subjectProgressData.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
                    <BookOpen className="h-12 w-12 mb-4 opacity-20" />
                    <p>No subjects added yet</p>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      layout="vertical"
                      data={subjectProgressData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis dataKey="name" type="category" width={80} />
                      <Tooltip formatter={(value) => [`${value}%`, 'Progress']} />
                      <Bar dataKey="progress" fill="#4e73df" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Weekly Achievements</CardTitle>
              <CardDescription>
                Your accomplishments this week
              </CardDescription>
            </CardHeader>
            <CardContent>
              {currentWeekSummary.achievements.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground">
                  <Award className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p>No achievements recorded for this week.</p>
                </div>
              ) : (
                <ScrollArea className="h-60">
                  <div className="space-y-4">
                    {currentWeekSummary.achievements.map((achievement, i) => (
                      <div key={i} className="flex items-center p-3 border rounded-lg">
                        <Award className="h-5 w-5 text-amber-500 mr-3" />
                        <div>
                          <div className="font-medium">{achievement}</div>
                          <div className="text-sm text-muted-foreground">
                            Week of {format(parseISO(currentWeekSummary.weekStartDate), 'MMM d')} - {format(parseISO(currentWeekSummary.weekEndDate), 'MMM d')}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function BookOpen(props: any) {
  return <Clock {...props} />;
}
