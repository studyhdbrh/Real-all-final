import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTests } from "@/hooks/use-tests";
import { ArrowUpIcon, ArrowDownIcon, PlusCircle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatDate } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getToday } from "@/lib/utils";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line
} from "recharts";

export function MarksTracker() {
  const { tests, getRecentTests, getTestsBySubject, getAverageScore, addTest, deleteTest } = useTests();
  const [isAddTestModalOpen, setIsAddTestModalOpen] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  
  const recentTests = getRecentTests(10);
  const subjects = Array.from(new Set(tests.map(test => test.subject)));
  const averageScore = getAverageScore();
  
  // Prepare data for charts
  const subjectAverages = subjects.map(subject => ({
    subject,
    average: getAverageScore(subject)
  }));
  
  const timelineData = selectedSubject 
    ? getTestsBySubject(selectedSubject).slice(-10).map(test => ({
        date: formatDate(test.date),
        score: test.score,
        maxScore: test.maxScore
      }))
    : [];
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Test Scores</h1>
        <Button 
          onClick={() => setIsAddTestModalOpen(true)}
          className="bg-primary hover:bg-primary/90"
        >
          <PlusCircle className="mr-1 h-4 w-4" /> Add Test Score
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageScore}/60</div>
            <p className="text-xs text-muted-foreground">Overall average across all tests</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Tests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tests.length}</div>
            <p className="text-xs text-muted-foreground">Tests recorded so far</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Best Subject</CardTitle>
          </CardHeader>
          <CardContent>
            {subjectAverages.length > 0 ? (
              <>
                <div className="text-2xl font-bold">
                  {subjectAverages.sort((a, b) => b.average - a.average)[0]?.subject}
                </div>
                <p className="text-xs text-muted-foreground">
                  Average: {subjectAverages.sort((a, b) => b.average - a.average)[0]?.average}/60
                </p>
              </>
            ) : (
              <div className="text-muted-foreground">No tests recorded yet</div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Subject Performance</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            {subjectAverages.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subjectAverages}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="subject" />
                  <YAxis domain={[0, 60]} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="average" name="Average Score" fill="#4e73df" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                No test data available.
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Score Timeline</CardTitle>
              <Select value={selectedSubject || ""} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Subjects</SelectItem>
                  {subjects.map(subject => (
                    <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="h-80">
            {timelineData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelineData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[0, 60]} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="score" name="Score" stroke="#4e73df" />
                  <Line type="monotone" dataKey="maxScore" name="Max Score" stroke="#dddfeb" strokeDasharray="5 5" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                {selectedSubject 
                  ? `No test data available for ${selectedSubject}.` 
                  : "Select a subject to view timeline."}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Recent Test Scores</CardTitle>
        </CardHeader>
        <CardContent>
          {recentTests.length === 0 ? (
            <div className="text-center py-6 text-gray-500">
              No test scores added yet. Add your first test result!
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-800">
                  <tr>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Subject
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Topic
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Score
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Change
                    </th>
                    <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-darkSurface divide-y divide-gray-200 dark:divide-gray-700">
                  {recentTests.map((test) => (
                    <tr key={test.id}>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        {formatDate(test.date)}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-white">
                        {test.subject}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        {test.topic}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        {test.score}/{test.maxScore}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm">
                        {test.change > 0 ? (
                          <span className="text-secondary flex items-center">
                            <ArrowUpIcon className="h-3 w-3 mr-1" /> +{test.change}
                          </span>
                        ) : test.change < 0 ? (
                          <span className="text-red-500 flex items-center">
                            <ArrowDownIcon className="h-3 w-3 mr-1" /> {test.change}
                          </span>
                        ) : (
                          <span className="text-gray-500">0</span>
                        )}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-700"
                          onClick={() => deleteTest(test.id)}
                        >
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      
      <AddTestModal
        isOpen={isAddTestModalOpen}
        onClose={() => setIsAddTestModalOpen(false)}
        onAddTest={addTest}
      />
    </>
  );
}

interface AddTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTest: (test: any) => void;
}

function AddTestModal({ isOpen, onClose, onAddTest }: AddTestModalProps) {
  const [subject, setSubject] = useState("");
  const [topic, setTopic] = useState("");
  const [score, setScore] = useState<number>(0);
  const [maxScore, setMaxScore] = useState<number>(60);
  const [date, setDate] = useState(getToday());
  
  const handleSubmit = () => {
    if (!subject || !topic) return;
    
    onAddTest({
      subject,
      topic,
      score,
      maxScore,
      date
    });
    
    // Reset form
    setSubject("");
    setTopic("");
    setScore(0);
    setMaxScore(60);
    setDate(getToday());
    
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Test</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger>
                <SelectValue placeholder="Select subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Physics">Physics</SelectItem>
                <SelectItem value="Chemistry">Chemistry</SelectItem>
                <SelectItem value="Mathematics">Mathematics</SelectItem>
                <SelectItem value="Biology">Biology</SelectItem>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="Social Studies">Social Studies</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="topic">Topic</Label>
            <Input 
              id="topic" 
              value={topic} 
              onChange={(e) => setTopic(e.target.value)} 
              placeholder="e.g. Electrostatics"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="score">Your Score</Label>
              <Input 
                id="score" 
                type="number" 
                min={0}
                max={maxScore}
                value={score} 
                onChange={(e) => setScore(Number(e.target.value))} 
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="maxScore">Maximum Score</Label>
              <Input 
                id="maxScore" 
                type="number" 
                min={1}
                value={maxScore} 
                onChange={(e) => setMaxScore(Number(e.target.value))} 
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="date">Test Date</Label>
            <Input 
              id="date" 
              type="date" 
              value={date} 
              max={getToday()}
              onChange={(e) => setDate(e.target.value)} 
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!subject || !topic}>
            Add Test
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
