import { useState } from "react";
import { Sidebar } from "./sidebar";
import { MobileNavbar } from "./mobile-navbar";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { UserProfileDisplay } from "@/components/ui/user-profile";
import { Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useLocation } from "wouter";
import { format } from "date-fns";

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export function AppLayout({ children, title = "Dashboard" }: AppLayoutProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100 dark:bg-darkBg">
      {/* Desktop Sidebar */}
      <Sidebar />
      
      {/* Mobile Sidebar */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetTrigger asChild>
          <button
            type="button"
            className="text-gray-600 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white focus:outline-none md:hidden"
          >
            <Menu className="h-6 w-6" />
          </button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-64 sm:max-w-sm">
          <Sidebar />
        </SheetContent>
      </Sheet>
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="bg-white dark:bg-darkSurface shadow flex items-center justify-between h-16 px-4 md:px-6">
          <div className="flex items-center md:hidden">
            <button
              type="button"
              className="text-gray-600 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white focus:outline-none"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </button>
            <h1 className="text-xl font-semibold text-primary ml-4">StudyTrack</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <UserProfileDisplay />
          </div>
        </header>
        
        {/* Page content */}
        <div className="flex-1 overflow-auto p-4 md:p-6 pb-16 md:pb-6">
          {/* Dashboard title */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-white">{title}</h2>
            <div>
              <span className="text-sm text-gray-600 dark:text-gray-300">Today: </span>
              <span className="text-sm font-medium">{format(new Date(), 'MMM dd, yyyy')}</span>
            </div>
          </div>
          
          {/* Page specific content */}
          {children}
        </div>
      </main>
      
      {/* Mobile navigation */}
      <MobileNavbar />
    </div>
  );
}
