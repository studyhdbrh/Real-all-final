import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Calendar,
  BookOpen,
  Award,
  Clock,
  FileBarChart2,
  ListTodo,
  Settings,
  Flame,
  Backpack,
  Timer,
  FileText
} from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();

  const navigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Holiday Manager", href: "/holidays", icon: Calendar },
    { name: "Streak Manager", href: "/streak", icon: Flame },
    { name: "Syllabus Tracker", href: "/syllabus", icon: BookOpen },
    { name: "Marks & Tests", href: "/marks", icon: FileBarChart2 },
    { name: "Calendar", href: "/calendar", icon: Calendar },
    { name: "Backlog Manager", href: "/backlog", icon: Clock },
    { name: "Achievements", href: "/achievements", icon: Award },
    { name: "Pomodoro Timer", href: "/pomodoro", icon: Timer },
    { name: "Summaries", href: "/summary", icon: FileText },
    { name: "Settings", href: "/settings", icon: Settings },
  ];

  return (
    <aside className="w-64 flex-shrink-0 hidden md:flex flex-col border-r border-gray-200 dark:border-gray-700 bg-white dark:bg-darkSurface">
      <div className="flex items-center justify-center h-16 border-b border-gray-200 dark:border-gray-700 px-4">
        <h1 className="text-2xl font-semibold text-primary">StudyTrack</h1>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-2 px-4">
          {navigation.map((item) => (
            <li key={item.name}>
              <Link href={item.href}>
                <div
                  className={cn(
                    "flex items-center p-2 text-base font-medium rounded-lg cursor-pointer",
                    location === item.href
                      ? "bg-primary bg-opacity-10 text-primary dark:text-primary"
                      : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                  )}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  <span>{item.name}</span>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}
