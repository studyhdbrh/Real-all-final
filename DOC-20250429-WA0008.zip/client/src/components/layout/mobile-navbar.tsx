import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Calendar,
  BookOpen,
  MoreHorizontal
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function MobileNavbar() {
  const [location] = useLocation();

  const mainNavItems = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Holidays", href: "/holidays", icon: Calendar },
    { name: "Syllabus", href: "/syllabus", icon: BookOpen },
  ];

  const dropdownNavItems = [
    { name: "Streak Manager", href: "/streak" },
    { name: "Marks & Tests", href: "/marks" },
    { name: "Calendar", href: "/calendar" },
    { name: "Backlog Manager", href: "/backlog" },
    { name: "Achievements", href: "/achievements" },
    { name: "Pomodoro Timer", href: "/pomodoro" },
    { name: "Summaries", href: "/summary" },
    { name: "Settings", href: "/settings" },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-darkSurface border-t border-gray-200 dark:border-gray-700 flex justify-around py-2 z-10">
      {mainNavItems.map((item) => (
        <Link key={item.name} href={item.href}>
          <div
            className={cn(
              "flex flex-col items-center p-2 cursor-pointer",
              location === item.href
                ? "text-primary"
                : "text-gray-600 dark:text-gray-400"
            )}
          >
            <item.icon className="h-5 w-5" />
            <span className="text-xs mt-1">{item.name}</span>
          </div>
        </Link>
      ))}
      
      <DropdownMenu>
        <DropdownMenuTrigger className="flex flex-col items-center p-2 text-gray-600 dark:text-gray-400" asChild>
          <button>
            <MoreHorizontal className="h-5 w-5" />
            <span className="text-xs mt-1">More</span>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {dropdownNavItems.map((item) => (
            <Link key={item.name} href={item.href}>
              <DropdownMenuItem className="cursor-pointer">
                {item.name}
              </DropdownMenuItem>
            </Link>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
