import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { usePomodoro } from "@/hooks/use-pomodoro";
import { formatTimeFromSeconds } from "@/lib/utils";
import { Play, Pause, RefreshCw, Settings2, Bell, BellOff, VolumeX, Volume2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import useLocalStorage from "@/hooks/use-local-storage";

export function PomodoroPage() {
  const { state, settings, start, pause, resume, reset, updateSettings } = usePomodoro();
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [newSettings, setNewSettings] = useState(settings);
  const [showPomodoroHistory, setShowPomodoroHistory] = useState(false);
  const [soundEnabled, setSoundEnabled] = useLocalStorage<boolean>("pomodoro-sound-enabled", true);
  const [notificationsEnabled, setNotificationsEnabled] = useLocalStorage<boolean>("pomodoro-notifications-enabled", true);
  
  // Calculate the percentage for the circle progress
  const percentage = (state.timeLeft / ((state.isBreak ? settings.breakTime : settings.focusTime) * 60)) * 100;
  const circleDashOffset = 283 - (283 * percentage) / 100;
  
  // Log for pomodoro sessions
  const [pomodoroLog, setPomodoroLog] = useLocalStorage<{
    date: string;
    focusSessions: number;
    breakSessions: number;
    totalFocusMinutes: number;
  }[]>("pomodoro-log", []);
  
  // Update log when a session completes
  const handleSessionComplete = () => {
    const today = new Date().toISOString().split('T')[0];
    
    setPomodoroLog(prevLog => {
      // Find today's log entry
      const todayLog = prevLog.find(log => log.date === today);
      
      if (todayLog) {
        // Update existing entry
        return prevLog.map(log => {
          if (log.date === today) {
            return {
              ...log,
              focusSessions: state.isBreak ? log.focusSessions + 1 : log.focusSessions,
              breakSessions: !state.isBreak ? log.breakSessions + 1 : log.breakSessions,
              totalFocusMinutes: state.isBreak 
                ? log.totalFocusMinutes + settings.focusTime
                : log.totalFocusMinutes
            };
          }
          return log;
        });
      } else {
        // Create new entry
        return [
          ...prevLog,
          {
            date: today,
            focusSessions: state.isBreak ? 1 : 0,
            breakSessions: !state.isBreak ? 1 : 0,
            totalFocusMinutes: state.isBreak ? settings.focusTime : 0
          }
        ];
      }
    });
  };
  
  // Play sound when timer ends
  const playTimerEndSound = () => {
    if (soundEnabled) {
      const audio = new Audio("https://assets.mixkit.co/sfx/preview/mixkit-alarm-digital-clock-beep-989.mp3");
      audio.play();
    }
  };
  
  // Show notification when timer ends
  const showTimerEndNotification = () => {
    if (notificationsEnabled && "Notification" in window) {
      if (Notification.permission === "granted") {
        new Notification(state.isBreak ? "Break time!" : "Focus time!", {
          body: state.isBreak 
            ? "Time to take a break!" 
            : "Time to focus on your work!",
          icon: "/favicon.ico"
        });
      } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then(permission => {
          if (permission === "granted") {
            showTimerEndNotification();
          }
        });
      }
    }
  };
  
  const handleSaveSettings = () => {
    updateSettings(newSettings);
    setIsSettingsModalOpen(false);
  };
  
  const handleResetSettings = () => {
    setNewSettings({
      focusTime: 25,
      breakTime: 5,
      cycles: 4
    });
  };
  
  const toggleSound = () => {
    setSoundEnabled(!soundEnabled);
  };
  
  const toggleNotifications = () => {
    if (!notificationsEnabled && "Notification" in window) {
      Notification.requestPermission();
    }
    setNotificationsEnabled(!notificationsEnabled);
  };
  
  // Get today's log entry
  const today = new Date().toISOString().split('T')[0];
  const todayLog = pomodoroLog.find(log => log.date === today) || {
    date: today,
    focusSessions: 0,
    breakSessions: 0,
    totalFocusMinutes: 0
  };
  
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Pomodoro Timer</CardTitle>
              <CardDescription>
                Stay focused with timed work sessions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center">
                <div className="relative mb-8 w-64 h-64">
                  <svg className="w-full h-full" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="45" fill="none" stroke="#e2e8f0" strokeWidth="8" />
                    <circle 
                      cx="50" 
                      cy="50" 
                      r="45" 
                      fill="none" 
                      stroke={state.isBreak ? "#1cc88a" : "#4e73df"} 
                      strokeWidth="8" 
                      strokeDasharray="283" 
                      strokeDashoffset={circleDashOffset}
                      transform="rotate(-90 50 50)" 
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="text-4xl font-bold mb-2">{formatTimeFromSeconds(state.timeLeft)}</div>
                    <div className="text-lg font-medium">
                      {state.isBreak ? "Break Time" : "Focus Time"}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Cycle {state.currentCycle}/{state.totalCycles}
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-8 w-full max-w-md">
                  {!state.isActive ? (
                    <Button 
                      className="col-span-2 bg-primary hover:bg-primary/90 text-white" 
                      onClick={start}
                    >
                      <Play className="mr-1 h-4 w-4" /> Start
                    </Button>
                  ) : state.isPaused ? (
                    <Button 
                      className="col-span-2 bg-primary hover:bg-primary/90 text-white" 
                      onClick={resume}
                    >
                      <Play className="mr-1 h-4 w-4" /> Resume
                    </Button>
                  ) : (
                    <Button 
                      className="col-span-2 bg-primary hover:bg-primary/90 text-white" 
                      onClick={pause}
                    >
                      <Pause className="mr-1 h-4 w-4" /> Pause
                    </Button>
                  )}
                  
                  <Button 
                    variant="outline" 
                    onClick={reset}
                  >
                    <RefreshCw className="mr-1 h-4 w-4" /> Reset
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={() => setIsSettingsModalOpen(true)}
                  >
                    <Settings2 className="mr-1 h-4 w-4" /> Settings
                  </Button>
                </div>
                
                <div className="flex space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleSound}
                    className="flex items-center text-sm"
                  >
                    {soundEnabled ? (
                      <>
                        <Volume2 className="h-4 w-4 mr-1" /> Sound On
                      </>
                    ) : (
                      <>
                        <VolumeX className="h-4 w-4 mr-1" /> Sound Off
                      </>
                    )}
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleNotifications}
                    className="flex items-center text-sm"
                  >
                    {notificationsEnabled ? (
                      <>
                        <Bell className="h-4 w-4 mr-1" /> Notifications On
                      </>
                    ) : (
                      <>
                        <BellOff className="h-4 w-4 mr-1" /> Notifications Off
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Pomodoro Technique</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  The Pomodoro Technique is a time management method that uses a timer to break down work into intervals, traditionally 25 minutes in length, separated by short breaks.
                </p>
                
                <h3 className="font-medium text-lg">How It Works:</h3>
                
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Decide on the task to be done</li>
                  <li>Set the timer for 25 minutes (a "Pomodoro")</li>
                  <li>Work on the task until the timer rings</li>
                  <li>Take a short break (5 minutes)</li>
                  <li>After 4 Pomodoros, take a longer break (15-30 minutes)</li>
                </ol>
                
                <h3 className="font-medium text-lg">Benefits:</h3>
                
                <ul className="list-disc pl-5 space-y-2">
                  <li>Improves focus and concentration</li>
                  <li>Reduces fatigue and burnout</li>
                  <li>Helps track productivity</li>
                  <li>Limits distractions and interruptions</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Today's Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">{todayLog.totalFocusMinutes}</div>
                  <div className="text-sm text-muted-foreground">Total Focus Minutes</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-xl font-bold">{todayLog.focusSessions}</div>
                    <div className="text-sm text-muted-foreground">Focus Sessions</div>
                  </div>
                  
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-xl font-bold">{todayLog.breakSessions}</div>
                    <div className="text-sm text-muted-foreground">Break Sessions</div>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setShowPomodoroHistory(true)}
                >
                  View History
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Current Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Focus Time:</span>
                  <Badge variant="outline">{settings.focusTime} minutes</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Break Time:</span>
                  <Badge variant="outline">{settings.breakTime} minutes</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Cycles per Set:</span>
                  <Badge variant="outline">{settings.cycles}</Badge>
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full mt-4"
                onClick={() => setIsSettingsModalOpen(true)}
              >
                <Settings2 className="mr-1 h-4 w-4" /> Adjust Settings
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Settings Modal */}
      <Dialog open={isSettingsModalOpen} onOpenChange={setIsSettingsModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Pomodoro Settings</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="focusTime">Focus Time (minutes)</Label>
              <div className="flex items-center space-x-2">
                <Slider
                  id="focusTime"
                  min={1}
                  max={60}
                  step={1}
                  value={[newSettings.focusTime]}
                  onValueChange={(value) => setNewSettings({...newSettings, focusTime: value[0]})}
                  className="flex-1"
                />
                <Input
                  type="number"
                  value={newSettings.focusTime}
                  onChange={(e) => setNewSettings({...newSettings, focusTime: parseInt(e.target.value) || 25})}
                  min={1}
                  max={60}
                  className="w-16 text-center"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="breakTime">Break Time (minutes)</Label>
              <div className="flex items-center space-x-2">
                <Slider
                  id="breakTime"
                  min={1}
                  max={30}
                  step={1}
                  value={[newSettings.breakTime]}
                  onValueChange={(value) => setNewSettings({...newSettings, breakTime: value[0]})}
                  className="flex-1"
                />
                <Input
                  type="number"
                  value={newSettings.breakTime}
                  onChange={(e) => setNewSettings({...newSettings, breakTime: parseInt(e.target.value) || 5})}
                  min={1}
                  max={30}
                  className="w-16 text-center"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="cycles">Cycles per Set</Label>
              <div className="flex items-center space-x-2">
                <Slider
                  id="cycles"
                  min={1}
                  max={10}
                  step={1}
                  value={[newSettings.cycles]}
                  onValueChange={(value) => setNewSettings({...newSettings, cycles: value[0]})}
                  className="flex-1"
                />
                <Input
                  type="number"
                  value={newSettings.cycles}
                  onChange={(e) => setNewSettings({...newSettings, cycles: parseInt(e.target.value) || 4})}
                  min={1}
                  max={10}
                  className="w-16 text-center"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2 pt-2">
              <Switch
                id="notifications"
                checked={notificationsEnabled}
                onCheckedChange={toggleNotifications}
              />
              <Label htmlFor="notifications">Enable notifications</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="sound"
                checked={soundEnabled}
                onCheckedChange={toggleSound}
              />
              <Label htmlFor="sound">Enable sound alerts</Label>
            </div>
          </div>
          
          <DialogFooter className="flex justify-between">
            <Button variant="outline" onClick={handleResetSettings}>
              Reset to Default
            </Button>
            <div className="space-x-2">
              <Button variant="outline" onClick={() => setIsSettingsModalOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveSettings}>
                Save Changes
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* History Modal */}
      <Dialog open={showPomodoroHistory} onOpenChange={setShowPomodoroHistory}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Pomodoro History</DialogTitle>
          </DialogHeader>
          
          <Tabs defaultValue="daily">
            <TabsList className="mb-4">
              <TabsTrigger value="daily">Daily Activity</TabsTrigger>
              <TabsTrigger value="weekly">Weekly Summary</TabsTrigger>
            </TabsList>
            
            <TabsContent value="daily">
              <ScrollArea className="h-[300px]">
                <div className="space-y-4">
                  {pomodoroLog.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No pomodoro sessions recorded yet.
                    </div>
                  ) : (
                    pomodoroLog
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map(log => (
                        <div key={log.date} className="border rounded-lg p-4">
                          <div className="flex justify-between items-center mb-3">
                            <h3 className="font-medium">{new Date(log.date).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</h3>
                            <Badge>{log.totalFocusMinutes} mins</Badge>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-3">
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-primary mr-2"></div>
                              <span className="text-sm">{log.focusSessions} Focus Sessions</span>
                            </div>
                            
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-secondary mr-2"></div>
                              <span className="text-sm">{log.breakSessions} Break Sessions</span>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="weekly">
              <div className="p-4">
                {pomodoroLog.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No data available for weekly summary.
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary">
                        {pomodoroLog.reduce((sum, log) => sum + log.totalFocusMinutes, 0)}
                      </div>
                      <div className="text-sm text-muted-foreground">Total Focus Minutes</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-muted rounded-lg">
                        <div className="text-xl font-bold">
                          {pomodoroLog.reduce((sum, log) => sum + log.focusSessions, 0)}
                        </div>
                        <div className="text-sm text-muted-foreground">Total Focus Sessions</div>
                      </div>
                      
                      <div className="text-center p-4 bg-muted rounded-lg">
                        <div className="text-xl font-bold">
                          {pomodoroLog.reduce((sum, log) => sum + log.breakSessions, 0)}
                        </div>
                        <div className="text-sm text-muted-foreground">Total Break Sessions</div>
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <h3 className="font-medium mb-2">Average Daily Focus:</h3>
                      <div className="text-lg font-bold">
                        {Math.round(pomodoroLog.reduce((sum, log) => sum + log.totalFocusMinutes, 0) / pomodoroLog.length)} minutes
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  );
}
