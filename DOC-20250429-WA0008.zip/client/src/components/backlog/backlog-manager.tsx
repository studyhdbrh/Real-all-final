import { useState } from "react";
import { useTasks } from "@/hooks/use-tasks";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatDate } from "@/lib/utils";
import { PlusCircle, Clock, Search, Calendar, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { getToday } from "@/lib/utils";
import { cn } from "@/lib/utils";

export function BacklogManager() {
  const { getBacklogTasks, moveTaskToToday, deleteTask, addTask } = useTasks();
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  
  const backlogTasks = getBacklogTasks();
  const filteredTasks = backlogTasks.filter(task => 
    task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (task.description && task.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  const categoryMap = new Map<string, typeof backlogTasks>();
  
  // Group by subject/category (first word of title is usually the subject)
  backlogTasks.forEach(task => {
    const category = task.title.split(' ')[0];
    if (!categoryMap.has(category)) {
      categoryMap.set(category, []);
    }
    categoryMap.get(category)!.push(task);
  });
  
  // New Task State
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    startTime: "09:00",
    endTime: "10:00",
    date: "",
    isImportant: false,
    isCritical: false
  });
  
  const handleAddTask = () => {
    if (!newTask.title || !newTask.date) return;
    
    addTask({
      title: newTask.title,
      description: newTask.description,
      startTime: newTask.startTime,
      endTime: newTask.endTime,
      date: newTask.date,
      isCompleted: false,
      isImportant: newTask.isImportant,
      isCritical: newTask.isCritical
    });
    
    // Reset form
    setNewTask({
      title: "",
      description: "",
      startTime: "09:00",
      endTime: "10:00",
      date: "",
      isImportant: false,
      isCritical: false
    });
    
    setIsAddTaskModalOpen(false);
  };
  
  return (
    <>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Backlog Manager</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Manage your pending tasks and move them to today's schedule
          </p>
        </div>
        
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tasks..."
              className="pl-8 w-[300px]"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm("")}
                className="absolute right-2 top-2.5 text-muted-foreground"
              >
                <XCircle className="h-4 w-4" />
              </button>
            )}
          </div>
          
          <Button onClick={() => setIsAddTaskModalOpen(true)}>
            <PlusCircle className="mr-1 h-4 w-4" /> Add Task
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="all">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Tasks ({backlogTasks.length})</TabsTrigger>
          {Array.from(categoryMap.keys()).map(category => (
            <TabsTrigger key={category} value={category}>
              {category} ({categoryMap.get(category)!.length})
            </TabsTrigger>
          ))}
        </TabsList>
        
        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTasks.length === 0 ? (
              <div className="col-span-full p-6 text-center">
                <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-1">
                  {searchTerm ? "No matching tasks found" : "No tasks in backlog"}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm 
                    ? "Try a different search term" 
                    : "You don't have any pending tasks in your backlog."}
                </p>
                {!searchTerm && (
                  <Button onClick={() => setIsAddTaskModalOpen(true)}>
                    <PlusCircle className="mr-1 h-4 w-4" /> Add Task
                  </Button>
                )}
              </div>
            ) : (
              filteredTasks.map(task => (
                <BacklogTaskCard
                  key={task.id}
                  task={task}
                  onMoveToToday={() => moveTaskToToday(task.id)}
                  onDelete={() => deleteTask(task.id)}
                />
              ))
            )}
          </div>
        </TabsContent>
        
        {Array.from(categoryMap.keys()).map(category => (
          <TabsContent key={category} value={category}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categoryMap.get(category)!.map(task => (
                <BacklogTaskCard
                  key={task.id}
                  task={task}
                  onMoveToToday={() => moveTaskToToday(task.id)}
                  onDelete={() => deleteTask(task.id)}
                />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
      
      {/* Add Task Modal */}
      <Dialog open={isAddTaskModalOpen} onOpenChange={setIsAddTaskModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Backlog Task</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="title">Task Title</Label>
              <Input 
                id="title" 
                value={newTask.title} 
                onChange={(e) => setNewTask({...newTask, title: e.target.value})} 
                placeholder="e.g. Physics - Mechanics Revision"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea 
                id="description" 
                value={newTask.description} 
                onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                placeholder="e.g. Complete all formulas and solve 10 problems" 
                rows={2}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="date">Original Due Date</Label>
              <Input 
                id="date" 
                type="date" 
                value={newTask.date} 
                max={getToday()}
                onChange={(e) => setNewTask({...newTask, date: e.target.value})} 
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startTime">Start Time</Label>
                <Input 
                  id="startTime" 
                  type="time" 
                  value={newTask.startTime} 
                  onChange={(e) => setNewTask({...newTask, startTime: e.target.value})} 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="endTime">End Time</Label>
                <Input 
                  id="endTime" 
                  type="time" 
                  value={newTask.endTime} 
                  onChange={(e) => setNewTask({...newTask, endTime: e.target.value})} 
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="important"
                  checked={newTask.isImportant}
                  onCheckedChange={(checked) => setNewTask({...newTask, isImportant: checked})}
                />
                <Label htmlFor="important">Important</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="critical"
                  checked={newTask.isCritical}
                  onCheckedChange={(checked) => setNewTask({...newTask, isCritical: checked})}
                />
                <Label htmlFor="critical">Critical</Label>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddTaskModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddTask}
              disabled={!newTask.title || !newTask.date}
            >
              Add Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

interface BacklogTaskCardProps {
  task: any;
  onMoveToToday: () => void;
  onDelete: () => void;
}

function BacklogTaskCard({ task, onMoveToToday, onDelete }: BacklogTaskCardProps) {
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  
  // Calculate days overdue
  const today = new Date();
  const taskDate = new Date(task.date);
  const daysOverdue = Math.floor((today.getTime() - taskDate.getTime()) / (1000 * 60 * 60 * 24));
  
  return (
    <Card className={cn(
      "transition-all hover:shadow-md",
      task.isCritical && "border-l-4 border-l-red-500",
      task.isImportant && !task.isCritical && "border-l-4 border-l-yellow-500"
    )}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-base">{task.title}</CardTitle>
            <CardDescription className="text-xs flex items-center mt-1">
              <Calendar className="h-3 w-3 mr-1" /> Due: {formatDate(task.date)}
            </CardDescription>
          </div>
          <Badge 
            variant={daysOverdue > 7 ? "destructive" : daysOverdue > 3 ? "warning" : "outline"}
            className="text-xs"
          >
            {daysOverdue} {daysOverdue === 1 ? 'day' : 'days'} overdue
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {task.description && (
          <p className="text-sm text-muted-foreground mb-4">{task.description}</p>
        )}
        
        <div className="flex justify-between items-center">
          <Badge variant="secondary" className="text-xs">
            {task.startTime} - {task.endTime}
          </Badge>
          
          {showConfirmDelete ? (
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="destructive" 
                onClick={() => {
                  onDelete();
                  setShowConfirmDelete(false);
                }}
              >
                Confirm
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => setShowConfirmDelete(false)}
              >
                Cancel
              </Button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Button size="sm" onClick={onMoveToToday}>
                <PlusCircle className="h-3 w-3 mr-1" /> Add to Today
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="text-red-500" 
                onClick={() => setShowConfirmDelete(true)}
              >
                Delete
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
