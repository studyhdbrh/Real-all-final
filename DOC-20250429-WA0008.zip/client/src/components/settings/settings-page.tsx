import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { UserProfileForm, UserProfileDisplay } from "@/components/ui/user-profile";
import { useTheme } from "@/hooks/use-theme";
import { 
  Download, Upload, Save, User, Moon, Sun, Bell, Volume2, 
  RotateCcw, AlertCircle, Check, FileText, X
} from "lucide-react";
import useLocalStorage from "@/hooks/use-local-storage";
import { useTasks } from "@/hooks/use-tasks";
import { useHolidays } from "@/hooks/use-holidays";
import { useStreak } from "@/hooks/use-streak";
import { useSyllabus } from "@/hooks/use-syllabus";
import { useTests } from "@/hooks/use-tests";
import { usePomodoro } from "@/hooks/use-pomodoro";
import { UserProfile } from "@/types";
import { downloadObjectAsJson } from "@/lib/utils";
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter 
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

export function SettingsPage() {
  const { theme, toggleTheme } = useTheme();
  const [notificationsEnabled, setNotificationsEnabled] = useLocalStorage<boolean>("notifications-enabled", true);
  const [soundEnabled, setSoundEnabled] = useLocalStorage<boolean>("sound-enabled", true);
  const [profile, setProfile] = useLocalStorage<UserProfile>("study-track-profile", {
    name: "Raj Kumar",
    className: "Class XII",
    examName: "JEE Aspirant",
    photoUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80"
  });
  
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importData, setImportData] = useState("");
  const [importError, setImportError] = useState("");
  const [importSuccess, setImportSuccess] = useState(false);
  const [isImportPlanModalOpen, setIsImportPlanModalOpen] = useState(false);
  const [planData, setPlanData] = useState("");
  
  // Hooks for data access
  const { tasks, importTasks } = useTasks();
  const { holidays, importHolidays } = useHolidays();
  const { streakData, importStreakData } = useStreak();
  const { subjects, importSyllabus } = useSyllabus();
  const { tests, importTests } = useTests();
  const { settings, importSettings } = usePomodoro();
  
  const handleExportData = () => {
    const exportData = {
      profile,
      tasks,
      holidays,
      streakData,
      subjects,
      tests,
      pomodoroSettings: settings,
      theme,
      notificationsEnabled,
      soundEnabled,
      exportDate: new Date().toISOString()
    };
    
    downloadObjectAsJson(exportData, `studytrack_data_${new Date().toISOString().split('T')[0]}`);
  };
  
  const handleImportData = () => {
    try {
      setImportError("");
      setImportSuccess(false);
      
      const data = JSON.parse(importData);
      
      // Validate required data
      if (!data.tasks || !data.holidays || !data.streakData || !data.subjects || !data.tests) {
        throw new Error("Import data is missing required fields");
      }
      
      // Import all data
      if (data.profile) setProfile(data.profile);
      importTasks(data.tasks);
      importHolidays(data.holidays);
      importStreakData(data.streakData);
      importSyllabus(data.subjects);
      importTests(data.tests);
      if (data.pomodoroSettings) importSettings(data.pomodoroSettings);
      
      setImportSuccess(true);
      setTimeout(() => {
        setIsImportModalOpen(false);
        setImportData("");
        setImportSuccess(false);
      }, 1500);
      
    } catch (error) {
      console.error("Import error:", error);
      setImportError("Invalid data format. Please check your import file.");
    }
  };
  
  const handleImportPlan = () => {
    try {
      // Parse plans format: date task1; task2; task3
      const lines = planData.trim().split('\n');
      
      for (const line of lines) {
        const [dateStr, tasksStr] = line.split(' ', 2);
        if (!dateStr || !tasksStr) continue;
        
        // Validate date format (YYYY-MM-DD)
        if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
          setImportError(`Invalid date format in line: ${line}. Use YYYY-MM-DD format.`);
          return;
        }
        
        const tasks = tasksStr.split(';').map(task => task.trim()).filter(Boolean);
        
        // Create tasks for each task in the list
        tasks.forEach((taskTitle, index) => {
          const startHour = 9 + index; // Start at 9 AM, each task 1 hour apart
          const endHour = startHour + 1;
          
          const task = {
            title: taskTitle,
            description: "",
            startTime: `${startHour.toString().padStart(2, '0')}:00`,
            endTime: `${endHour.toString().padStart(2, '0')}:00`,
            date: dateStr,
            isCompleted: false,
            isImportant: false,
            isCritical: false
          };
          
          // Use the addTask function from useTasks (but we can't directly call hooks here)
          // This is a workaround - in a real app, you'd add tasks directly
          const existingTasks = JSON.parse(localStorage.getItem("study-track-tasks") || "[]");
          existingTasks.push({
            ...task,
            id: Math.random().toString(36).substring(2) + Date.now().toString(36)
          });
          localStorage.setItem("study-track-tasks", JSON.stringify(existingTasks));
        });
      }
      
      setImportSuccess(true);
      setTimeout(() => {
        setIsImportPlanModalOpen(false);
        setPlanData("");
        setImportSuccess(false);
        window.location.reload(); // Reload to reflect the changes
      }, 1500);
      
    } catch (error) {
      console.error("Import plan error:", error);
      setImportError("Failed to import plan. Please check the format.");
    }
  };
  
  const handleResetAll = () => {
    localStorage.clear();
    window.location.reload();
  };

  return (
    <div>
      <Tabs defaultValue="profile">
        <TabsList className="mb-6">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
          <TabsTrigger value="data">Data Management</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>User Profile</CardTitle>
                <CardDescription>
                  Update your personal information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <UserProfileForm 
                  profile={profile} 
                  onUpdate={setProfile} 
                />
                
                <Button className="mt-6">
                  <Save className="mr-2 h-4 w-4" /> Save Changes
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Your Profile</CardTitle>
                <CardDescription>
                  This is how others will see you
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center">
                <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border">
                  <img 
                    src={profile.photoUrl || "https://via.placeholder.com/100"} 
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <h3 className="text-xl font-bold mb-1">{profile.name}</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {profile.className} - {profile.examName}
                </p>
                
                <div className="w-full space-y-2 mt-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Current Streak:</span>
                    <Badge variant="outline">{streakData.currentStreak} days</Badge>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Tasks Completed:</span>
                    <Badge variant="outline">{tasks.filter(t => t.isCompleted).length}</Badge>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Average Score:</span>
                    <Badge variant="outline">
                      {tests.length > 0 
                        ? (tests.reduce((sum, test) => sum + test.score, 0) / tests.length).toFixed(1)
                        : "N/A"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="preferences">
          <Card>
            <CardHeader>
              <CardTitle>App Preferences</CardTitle>
              <CardDescription>
                Customize your app experience
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Dark Mode</Label>
                  <div className="text-sm text-muted-foreground">
                    Switch between light and dark themes
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Sun className="h-5 w-5 text-muted-foreground" />
                  <Switch 
                    checked={theme === 'dark'} 
                    onCheckedChange={toggleTheme}
                  />
                  <Moon className="h-5 w-5 text-muted-foreground" />
                </div>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Notifications</Label>
                  <div className="text-sm text-muted-foreground">
                    Enable task and study time notifications
                  </div>
                </div>
                <Switch 
                  checked={notificationsEnabled} 
                  onCheckedChange={setNotificationsEnabled}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Sound Effects</Label>
                  <div className="text-sm text-muted-foreground">
                    Enable sound alerts for timers and notifications
                  </div>
                </div>
                <Switch 
                  checked={soundEnabled} 
                  onCheckedChange={setSoundEnabled}
                />
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <Label className="text-base">Pomodoro Settings</Label>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>Focus Time</Label>
                    <div className="flex items-center mt-1">
                      <Input 
                        type="number" 
                        value={settings.focusTime} 
                        disabled
                        className="w-16 mr-2"
                      />
                      <span className="text-muted-foreground text-sm">minutes</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label>Break Time</Label>
                    <div className="flex items-center mt-1">
                      <Input 
                        type="number" 
                        value={settings.breakTime} 
                        disabled
                        className="w-16 mr-2"
                      />
                      <span className="text-muted-foreground text-sm">minutes</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label>Cycles</Label>
                    <div className="flex items-center mt-1">
                      <Input 
                        type="number" 
                        value={settings.cycles} 
                        disabled
                        className="w-16 mr-2"
                      />
                      <span className="text-muted-foreground text-sm">per set</span>
                    </div>
                  </div>
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  *To change these settings, go to the Pomodoro Timer page
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="data">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Export & Import</CardTitle>
                <CardDescription>
                  Save or restore your study data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-medium">Export Data</h3>
                  <p className="text-sm text-muted-foreground">
                    Export all your tasks, streaks, subjects, and settings to a file that you can save or share.
                  </p>
                  <Button onClick={handleExportData} className="w-full">
                    <Download className="mr-2 h-4 w-4" /> Export All Data
                  </Button>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <h3 className="font-medium">Import Data</h3>
                  <p className="text-sm text-muted-foreground">
                    Import previously exported data. This will overwrite your current data.
                  </p>
                  <Button onClick={() => setIsImportModalOpen(true)} variant="outline" className="w-full">
                    <Upload className="mr-2 h-4 w-4" /> Import Data
                  </Button>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <h3 className="font-medium">Import Plans</h3>
                  <p className="text-sm text-muted-foreground">
                    Import plans directly in the format: date task1; task2; task3
                  </p>
                  <Button onClick={() => setIsImportPlanModalOpen(true)} variant="outline" className="w-full">
                    <FileText className="mr-2 h-4 w-4" /> Import Plans
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Data Management</CardTitle>
                <CardDescription>
                  Manage your app data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <h3 className="font-medium">Storage Usage</h3>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Tasks</span>
                      <span>{tasks.length} entries</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Holidays</span>
                      <span>{holidays.length} entries</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Subjects</span>
                      <span>{subjects.length} entries</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Test Scores</span>
                      <span>{tests.length} entries</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Danger Zone</AlertTitle>
                    <AlertDescription>
                      Resetting your data will permanently delete all your tasks, streaks, and settings.
                    </AlertDescription>
                  </Alert>
                  
                  <Button 
                    variant="destructive" 
                    className="w-full mt-2"
                    onClick={() => setIsResetConfirmOpen(true)}
                  >
                    <RotateCcw className="mr-2 h-4 w-4" /> Reset All Data
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Import Data Modal */}
      <Dialog open={isImportModalOpen} onOpenChange={setIsImportModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Data</DialogTitle>
          </DialogHeader>
          
          {importSuccess ? (
            <div className="py-6 text-center">
              <div className="flex justify-center mb-4">
                <div className="rounded-full p-2 bg-green-100 text-green-600">
                  <Check className="h-8 w-8" />
                </div>
              </div>
              <h3 className="text-xl font-medium mb-2">Import Successful</h3>
              <p className="text-muted-foreground">Your data has been imported successfully.</p>
            </div>
          ) : (
            <>
              <div className="space-y-4 py-4">
                <Label htmlFor="importData">Paste your exported data below:</Label>
                <Textarea
                  id="importData"
                  placeholder='{"profile": {...}, "tasks": [...], ...}'
                  rows={10}
                  value={importData}
                  onChange={(e) => setImportData(e.target.value)}
                />
                
                {importError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{importError}</AlertDescription>
                  </Alert>
                )}
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsImportModalOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleImportData} disabled={!importData.trim()}>
                  Import
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Import Plan Modal */}
      <Dialog open={isImportPlanModalOpen} onOpenChange={setIsImportPlanModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Plans</DialogTitle>
          </DialogHeader>
          
          {importSuccess ? (
            <div className="py-6 text-center">
              <div className="flex justify-center mb-4">
                <div className="rounded-full p-2 bg-green-100 text-green-600">
                  <Check className="h-8 w-8" />
                </div>
              </div>
              <h3 className="text-xl font-medium mb-2">Import Successful</h3>
              <p className="text-muted-foreground">Your plans have been imported successfully.</p>
            </div>
          ) : (
            <>
              <div className="space-y-4 py-4">
                <Label htmlFor="planData">Enter plans in the format: date task1; task2; task3</Label>
                <Textarea
                  id="planData"
                  placeholder="2023-05-15 Physics - Mechanics; Chemistry - Organic Reactions"
                  rows={10}
                  value={planData}
                  onChange={(e) => setPlanData(e.target.value)}
                />
                
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>Example format:</p>
                  <pre className="bg-muted p-2 rounded">
                    2023-05-15 Physics - Mechanics; Chemistry - Organic Reactions{"\n"}
                    2023-05-16 Mathematics - Calculus; English - Essay Writing
                  </pre>
                </div>
                
                {importError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{importError}</AlertDescription>
                  </Alert>
                )}
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsImportPlanModalOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleImportPlan} disabled={!planData.trim()}>
                  Import Plans
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Reset Confirmation Dialog */}
      <Dialog open={isResetConfirmOpen} onOpenChange={setIsResetConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset All Data</DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Warning</AlertTitle>
              <AlertDescription>
                This action cannot be undone. All your data will be permanently deleted.
              </AlertDescription>
            </Alert>
            
            <p className="font-medium">Are you absolutely sure you want to reset all data?</p>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsResetConfirmOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleResetAll}>
              Yes, Reset Everything
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
