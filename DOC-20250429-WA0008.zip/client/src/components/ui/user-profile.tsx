import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserProfile } from "@/types";
import useLocalStorage from "@/hooks/use-local-storage";

export function UserProfileDisplay() {
  const [profile] = useLocalStorage<UserProfile>("study-track-profile", {
    name: "Raj Kumar",
    className: "Class XII",
    examName: "JEE Aspirant",
    photoUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80"
  });

  return (
    <div className="flex items-center">
      <Avatar className="h-9 w-9">
        <AvatarImage src={profile.photoUrl} alt={profile.name} />
        <AvatarFallback>{profile.name.charAt(0)}</AvatarFallback>
      </Avatar>
      <div className="ml-3 overflow-hidden">
        <p className="text-sm font-medium truncate">{profile.name}</p>
        <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
          {profile.className} - {profile.examName}
        </p>
      </div>
    </div>
  );
}

interface UserProfileFormProps {
  profile: UserProfile;
  onUpdate: (profile: UserProfile) => void;
}

export function UserProfileForm({ profile, onUpdate }: UserProfileFormProps) {
  return (
    <div className="space-y-4">
      <div className="flex flex-col space-y-2">
        <label className="text-sm font-medium">Name</label>
        <input
          type="text"
          value={profile.name}
          onChange={(e) => onUpdate({ ...profile, name: e.target.value })}
          className="border border-gray-300 dark:border-gray-600 dark:bg-gray-800 rounded-md px-3 py-2"
        />
      </div>
      
      <div className="flex flex-col space-y-2">
        <label className="text-sm font-medium">Class</label>
        <input
          type="text"
          value={profile.className}
          onChange={(e) => onUpdate({ ...profile, className: e.target.value })}
          className="border border-gray-300 dark:border-gray-600 dark:bg-gray-800 rounded-md px-3 py-2"
        />
      </div>
      
      <div className="flex flex-col space-y-2">
        <label className="text-sm font-medium">Exam</label>
        <input
          type="text"
          value={profile.examName}
          onChange={(e) => onUpdate({ ...profile, examName: e.target.value })}
          className="border border-gray-300 dark:border-gray-600 dark:bg-gray-800 rounded-md px-3 py-2"
        />
      </div>
      
      <div className="flex flex-col space-y-2">
        <label className="text-sm font-medium">Photo URL</label>
        <input
          type="text"
          value={profile.photoUrl || ''}
          onChange={(e) => onUpdate({ ...profile, photoUrl: e.target.value })}
          className="border border-gray-300 dark:border-gray-600 dark:bg-gray-800 rounded-md px-3 py-2"
        />
      </div>
    </div>
  );
}
