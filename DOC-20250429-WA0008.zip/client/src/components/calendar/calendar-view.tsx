import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, parse, isSameDay, isToday } from "date-fns";
import { useTasks } from "@/hooks/use-tasks";
import { useHolidays } from "@/hooks/use-holidays";
import { useStreak } from "@/hooks/use-streak";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { getToday } from "@/lib/utils";
import { Task } from "@/types";

export function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  const [isViewTasksModalOpen, setIsViewTasksModalOpen] = useState(false);
  const [dayTasks, setDayTasks] = useState<Task[]>([]);
  
  const { tasks, getTasksByDate, addTask } = useTasks();
  const { holidays, getHolidayByDate } = useHolidays();
  const { streakData } = useStreak();
  
  const startDate = startOfMonth(currentDate);
  const endDate = endOfMonth(currentDate);
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  // Group days into weeks
  const weeks: Date[][] = [];
  let currentWeek: Date[] = [];
  
  // Add days from previous month to fill first week
  const dayOfWeek = startDate.getDay();
  for (let i = 0; i < dayOfWeek; i++) {
    currentWeek.push(new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate() - dayOfWeek + i));
  }
  
  // Add all days
  days.forEach((day, i) => {
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
    currentWeek.push(day);
  });
  
  // Add days from next month to fill last week
  if (currentWeek.length > 0) {
    const daysToAdd = 7 - currentWeek.length;
    for (let i = 1; i <= daysToAdd; i++) {
      currentWeek.push(new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate() + i));
    }
    weeks.push(currentWeek);
  }
  
  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };
  
  const goToToday = () => {
    setCurrentDate(new Date());
  };
  
  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    const formattedDate = format(date, 'yyyy-MM-dd');
    const tasksForDay = getTasksByDate(formattedDate);
    setDayTasks(tasksForDay);
    setIsViewTasksModalOpen(true);
  };
  
  const getDayStatus = (date: Date): 'completed' | 'holiday' | 'missed' | null => {
    const formattedDate = format(date, 'yyyy-MM-dd');
    
    // Check if there's a holiday on this date
    const holiday = getHolidayByDate(formattedDate);
    if (holiday) return 'holiday';
    
    // Check streak status for the day
    const streakDay = streakData.lastTwoWeeks.find(day => day.date === formattedDate);
    if (streakDay) return streakDay.status;
    
    return null;
  };
  
  const getTaskCount = (date: Date): number => {
    const formattedDate = format(date, 'yyyy-MM-dd');
    return getTasksByDate(formattedDate).length;
  };
  
  // New Task State
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    startTime: "09:00",
    endTime: "10:00",
    isImportant: false,
    isCritical: false
  });
  
  const handleAddTask = () => {
    if (!selectedDate || !newTask.title) return;
    
    addTask({
      title: newTask.title,
      description: newTask.description,
      startTime: newTask.startTime,
      endTime: newTask.endTime,
      date: format(selectedDate, 'yyyy-MM-dd'),
      isCompleted: false,
      isImportant: newTask.isImportant,
      isCritical: newTask.isCritical
    });
    
    // Reset form
    setNewTask({
      title: "",
      description: "",
      startTime: "09:00",
      endTime: "10:00",
      isImportant: false,
      isCritical: false
    });
    
    setIsAddTaskModalOpen(false);
    
    // Refresh tasks for the day
    const updatedTasks = getTasksByDate(format(selectedDate, 'yyyy-MM-dd'));
    setDayTasks(updatedTasks);
  };
  
  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Calendar</CardTitle>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={goToPreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
            <Button variant="outline" size="sm" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-xl font-semibold mb-4 text-center">
            {format(currentDate, 'MMMM yyyy')}
          </div>
          
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-sm font-medium text-gray-500 py-1">
                {day}
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1 mb-4">
            {weeks.flat().map((day, i) => {
              const isCurrentMonth = day.getMonth() === currentDate.getMonth();
              const status = getDayStatus(day);
              const taskCount = getTaskCount(day);
              
              return (
                <button
                  key={i}
                  onClick={() => handleDateClick(day)}
                  className={cn(
                    "h-14 rounded-md flex flex-col items-center justify-center relative",
                    isCurrentMonth ? "bg-background dark:bg-gray-800" : "bg-muted dark:bg-gray-900 text-muted-foreground",
                    status === 'completed' && "bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300",
                    status === 'holiday' && "bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300",
                    status === 'missed' && "bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300",
                    isToday(day) && "border-2 border-primary"
                  )}
                >
                  <span className="text-sm font-medium">{format(day, 'd')}</span>
                  {taskCount > 0 && (
                    <Badge variant="secondary" className="absolute top-1 right-1 h-4 min-w-4 text-[10px] flex items-center justify-center">
                      {taskCount}
                    </Badge>
                  )}
                </button>
              );
            })}
          </div>
          
          <div className="flex justify-center space-x-6 text-xs">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-100 dark:bg-green-900 rounded-full mr-1"></div>
              <span>Completed</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-yellow-100 dark:bg-yellow-900 rounded-full mr-1"></div>
              <span>Holiday</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-100 dark:bg-red-900 rounded-full mr-1"></div>
              <span>Missed</span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* View Tasks Modal */}
      <Dialog open={isViewTasksModalOpen} onOpenChange={setIsViewTasksModalOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {selectedDate ? format(selectedDate, 'MMMM d, yyyy') : 'Tasks'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            {dayTasks.length === 0 ? (
              <div className="text-center text-gray-500 py-4">No tasks for this day</div>
            ) : (
              <div className="space-y-3">
                {dayTasks.map(task => (
                  <div 
                    key={task.id} 
                    className={cn(
                      "p-3 border rounded-lg",
                      task.isCritical && "border-l-4 border-l-red-500",
                      task.isImportant && !task.isCritical && "border-l-4 border-l-yellow-500"
                    )}
                  >
                    <div className="flex items-start">
                      <Checkbox 
                        checked={task.isCompleted} 
                        disabled 
                        className="mt-1 pointer-events-none"
                      />
                      <div className="ml-3">
                        <div className="flex justify-between">
                          <span className="font-medium">{task.title}</span>
                          <span className="text-xs text-gray-500">
                            {task.startTime} - {task.endTime}
                          </span>
                        </div>
                        {task.description && (
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {task.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              onClick={() => {
                setIsViewTasksModalOpen(false);
                setIsAddTaskModalOpen(true);
              }}
            >
              <Plus className="h-4 w-4 mr-1" /> Add Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Add Task Modal */}
      <Dialog open={isAddTaskModalOpen} onOpenChange={setIsAddTaskModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Add Task for {selectedDate ? format(selectedDate, 'MMMM d, yyyy') : 'today'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="title">Task Title</Label>
              <Input 
                id="title" 
                value={newTask.title} 
                onChange={(e) => setNewTask({...newTask, title: e.target.value})} 
                placeholder="e.g. Physics - Mechanics Revision"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea 
                id="description" 
                value={newTask.description} 
                onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                placeholder="e.g. Complete all formulas and solve 10 problems" 
                rows={2}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startTime">Start Time</Label>
                <Input 
                  id="startTime" 
                  type="time" 
                  value={newTask.startTime} 
                  onChange={(e) => setNewTask({...newTask, startTime: e.target.value})} 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="endTime">End Time</Label>
                <Input 
                  id="endTime" 
                  type="time" 
                  value={newTask.endTime} 
                  onChange={(e) => setNewTask({...newTask, endTime: e.target.value})} 
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="important"
                  checked={newTask.isImportant}
                  onCheckedChange={(checked) => setNewTask({...newTask, isImportant: checked})}
                />
                <Label htmlFor="important">Important</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="critical"
                  checked={newTask.isCritical}
                  onCheckedChange={(checked) => setNewTask({...newTask, isCritical: checked})}
                />
                <Label htmlFor="critical">Critical</Label>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddTaskModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddTask}
              disabled={!newTask.title}
            >
              Add Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
