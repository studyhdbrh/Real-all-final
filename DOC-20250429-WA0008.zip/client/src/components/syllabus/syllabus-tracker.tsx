import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useSyllabus } from "@/hooks/use-syllabus";
import { PlusCircle, BookOpen, Trash2, Edit } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreVertical } from "lucide-react";

export function SyllabusTracker() {
  const { 
    subjects, 
    addSubject, 
    updateSubject,
    deleteSubject,
    addChapter,
    updateChapter,
    deleteChapter,
    toggleChapterCompletion
  } = useSyllabus();
  
  const [isAddSubjectModalOpen, setIsAddSubjectModalOpen] = useState(false);
  const [isEditSubjectModalOpen, setIsEditSubjectModalOpen] = useState(false);
  const [isAddChapterModalOpen, setIsAddChapterModalOpen] = useState(false);
  const [isEditChapterModalOpen, setIsEditChapterModalOpen] = useState(false);
  
  const [newSubjectName, setNewSubjectName] = useState("");
  const [editingSubject, setEditingSubject] = useState<{ id: string, name: string } | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [newChapterName, setNewChapterName] = useState("");
  const [editingChapter, setEditingChapter] = useState<{ id: string, name: string, subjectId: string } | null>(null);
  
  const handleAddSubject = () => {
    if (newSubjectName.trim()) {
      addSubject(newSubjectName.trim());
      setNewSubjectName("");
      setIsAddSubjectModalOpen(false);
    }
  };
  
  const handleEditSubject = () => {
    if (editingSubject && editingSubject.name.trim()) {
      updateSubject(editingSubject.id, editingSubject.name.trim());
      setEditingSubject(null);
      setIsEditSubjectModalOpen(false);
    }
  };
  
  const handleDeleteSubject = (subjectId: string) => {
    if (confirm("Are you sure you want to delete this subject and all its chapters?")) {
      deleteSubject(subjectId);
    }
  };
  
  const handleAddChapter = () => {
    if (selectedSubjectId && newChapterName.trim()) {
      addChapter(selectedSubjectId, newChapterName.trim());
      setNewChapterName("");
      setIsAddChapterModalOpen(false);
    }
  };
  
  const handleEditChapter = () => {
    if (editingChapter && editingChapter.name.trim()) {
      updateChapter(editingChapter.subjectId, editingChapter.id, { name: editingChapter.name.trim() });
      setEditingChapter(null);
      setIsEditChapterModalOpen(false);
    }
  };
  
  const handleDeleteChapter = (subjectId: string, chapterId: string) => {
    if (confirm("Are you sure you want to delete this chapter?")) {
      deleteChapter(subjectId, chapterId);
    }
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Syllabus Tracker</h1>
        <Button 
          onClick={() => setIsAddSubjectModalOpen(true)}
          className="bg-primary hover:bg-primary/90"
        >
          <PlusCircle className="mr-1 h-4 w-4" /> Add Subject
        </Button>
      </div>
      
      {subjects.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">No subjects added yet</h3>
            <p className="text-gray-500 dark:text-gray-400 text-center mb-4">
              Start tracking your syllabus by adding your first subject.
            </p>
            <Button 
              onClick={() => setIsAddSubjectModalOpen(true)}
              className="bg-primary hover:bg-primary/90"
            >
              <PlusCircle className="mr-1 h-4 w-4" /> Add Subject
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {subjects.map((subject) => (
            <Card key={subject.id}>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>{subject.name}</CardTitle>
                <div className="flex items-center space-x-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={() => {
                          setEditingSubject({ id: subject.id, name: subject.name });
                          setIsEditSubjectModalOpen(true);
                        }}
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        <span>Edit Subject</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleDeleteSubject(subject.id)}
                        className="text-red-600"
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        <span>Delete Subject</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Button 
                    size="sm"
                    onClick={() => {
                      setSelectedSubjectId(subject.id);
                      setIsAddChapterModalOpen(true);
                    }}
                  >
                    <PlusCircle className="mr-1 h-4 w-4" /> Add Chapter
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Main Syllabus: {subject.mainProgress}%</span>
                      <span className="text-sm">Advanced: {subject.advancedProgress}%</span>
                    </div>
                    <div className="space-y-1">
                      <Progress value={subject.mainProgress} className="h-2 bg-gray-200 dark:bg-gray-700" indicatorClassName="bg-primary" />
                      <Progress value={subject.advancedProgress} className="h-2 bg-gray-200 dark:bg-gray-700" indicatorClassName="bg-secondary" />
                    </div>
                  </div>
                  
                  {subject.chapters.length === 0 ? (
                    <div className="text-center py-4 text-gray-500">
                      No chapters added yet. Add your first chapter.
                    </div>
                  ) : (
                    <Accordion type="multiple" className="w-full">
                      {subject.chapters.map((chapter) => (
                        <AccordionItem key={chapter.id} value={chapter.id}>
                          <AccordionTrigger className="hover:no-underline">
                            <div className="flex items-center justify-between w-full pr-4">
                              <span>{chapter.name}</span>
                              <div className="flex items-center space-x-2">
                                {chapter.isCompletedMain && (
                                  <span className="text-xs px-2 py-1 rounded-full bg-primary bg-opacity-10 text-primary">Main</span>
                                )}
                                {chapter.isCompletedAdvanced && (
                                  <span className="text-xs px-2 py-1 rounded-full bg-secondary bg-opacity-10 text-secondary">Advanced</span>
                                )}
                              </div>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent>
                            <div className="p-2 space-y-4">
                              <div className="flex items-center space-x-2">
                                <Checkbox 
                                  id={`main-${chapter.id}`} 
                                  checked={chapter.isCompletedMain}
                                  onCheckedChange={() => toggleChapterCompletion(subject.id, chapter.id, 'main')}
                                />
                                <Label htmlFor={`main-${chapter.id}`}>Completed (Main Level)</Label>
                              </div>
                              
                              <div className="flex items-center space-x-2">
                                <Checkbox 
                                  id={`advanced-${chapter.id}`} 
                                  checked={chapter.isCompletedAdvanced}
                                  onCheckedChange={() => toggleChapterCompletion(subject.id, chapter.id, 'advanced')}
                                />
                                <Label htmlFor={`advanced-${chapter.id}`}>Completed (JEE Advanced Level)</Label>
                              </div>
                              
                              <div className="flex justify-end space-x-2">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => {
                                    setEditingChapter({ 
                                      id: chapter.id, 
                                      name: chapter.name,
                                      subjectId: subject.id
                                    });
                                    setIsEditChapterModalOpen(true);
                                  }}
                                >
                                  <Edit className="mr-1 h-4 w-4" /> Edit
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="text-red-500"
                                  onClick={() => handleDeleteChapter(subject.id, chapter.id)}
                                >
                                  <Trash2 className="mr-1 h-4 w-4" /> Delete
                                </Button>
                              </div>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Add Subject Modal */}
      <Dialog open={isAddSubjectModalOpen} onOpenChange={setIsAddSubjectModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Subject</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="subject-name">Subject Name</Label>
              <Input 
                id="subject-name" 
                value={newSubjectName} 
                onChange={(e) => setNewSubjectName(e.target.value)} 
                placeholder="e.g. Physics, Chemistry, Mathematics"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddSubjectModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddSubject}
              disabled={!newSubjectName.trim()}
            >
              Add Subject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Subject Modal */}
      <Dialog open={isEditSubjectModalOpen} onOpenChange={setIsEditSubjectModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Subject</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="edit-subject-name">Subject Name</Label>
              <Input 
                id="edit-subject-name" 
                value={editingSubject?.name || ''} 
                onChange={(e) => setEditingSubject(prev => prev ? { ...prev, name: e.target.value } : null)} 
                placeholder="e.g. Physics, Chemistry, Mathematics"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditSubjectModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleEditSubject}
              disabled={!editingSubject?.name?.trim()}
            >
              Update Subject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Add Chapter Modal */}
      <Dialog open={isAddChapterModalOpen} onOpenChange={setIsAddChapterModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Chapter</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="chapter-name">Chapter Name</Label>
              <Input 
                id="chapter-name" 
                value={newChapterName} 
                onChange={(e) => setNewChapterName(e.target.value)} 
                placeholder="e.g. Mechanics, Organic Chemistry"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddChapterModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddChapter}
              disabled={!newChapterName.trim()}
            >
              Add Chapter
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Chapter Modal */}
      <Dialog open={isEditChapterModalOpen} onOpenChange={setIsEditChapterModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Chapter</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="edit-chapter-name">Chapter Name</Label>
              <Input 
                id="edit-chapter-name" 
                value={editingChapter?.name || ''} 
                onChange={(e) => setEditingChapter(prev => prev ? { ...prev, name: e.target.value } : null)} 
                placeholder="e.g. Mechanics, Organic Chemistry"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditChapterModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleEditChapter}
              disabled={!editingChapter?.name?.trim()}
            >
              Update Chapter
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
