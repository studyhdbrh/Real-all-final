import { pgTable, text, serial, integer, boolean, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  className: text("class_name"),
  examName: text("exam_name"),
  photoUrl: text("photo_url")
});

// Task table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  date: date("date").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  actualTimeTaken: integer("actual_time_taken"),
  isImportant: boolean("is_important").default(false),
  isCritical: boolean("is_critical").default(false),
  createdAt: timestamp("created_at").defaultNow()
});

// Holiday table
export const holidays = pgTable("holidays", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: date("date").notNull(),
  reason: text("reason").notNull(),
  isFullDay: boolean("is_full_day").notNull(),
  hours: integer("hours"),
  createdAt: timestamp("created_at").defaultNow()
});

// Subject table
export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  mainProgress: integer("main_progress").notNull().default(0),
  advancedProgress: integer("advanced_progress").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow()
});

// Chapter table
export const chapters = pgTable("chapters", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").notNull().references(() => subjects.id),
  name: text("name").notNull(),
  isCompletedMain: boolean("is_completed_main").notNull().default(false),
  isCompletedAdvanced: boolean("is_completed_advanced").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow()
});

// Test Marks table
export const tests = pgTable("tests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  subject: text("subject").notNull(),
  topic: text("topic").notNull(),
  score: integer("score").notNull(),
  maxScore: integer("max_score").notNull().default(60),
  change: integer("change"),
  date: date("date").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

// Schema for user insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  className: true,
  examName: true,
  photoUrl: true
});

// Schema for task insertion
export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true
});

// Schema for holiday insertion
export const insertHolidaySchema = createInsertSchema(holidays).omit({
  id: true,
  createdAt: true
});

// Schema for subject insertion
export const insertSubjectSchema = createInsertSchema(subjects).omit({
  id: true,
  mainProgress: true,
  advancedProgress: true,
  createdAt: true
});

// Schema for chapter insertion
export const insertChapterSchema = createInsertSchema(chapters).omit({
  id: true,
  createdAt: true
});

// Schema for test insertion
export const insertTestSchema = createInsertSchema(tests).omit({
  id: true,
  change: true,
  createdAt: true
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertHoliday = z.infer<typeof insertHolidaySchema>;
export type Holiday = typeof holidays.$inferSelect;

export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type Subject = typeof subjects.$inferSelect;

export type InsertChapter = z.infer<typeof insertChapterSchema>;
export type Chapter = typeof chapters.$inferSelect;

export type InsertTest = z.infer<typeof insertTestSchema>;
export type Test = typeof tests.$inferSelect;
