import { 
  InsertTask, Task, InsertHoliday, Holiday, 
  InsertSubject, Subject, InsertChapter, Chapter, 
  InsertTest, Test, InsertUser, User
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Task methods
  getAllTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task>;
  deleteTask(id: number): Promise<void>;
  
  // Holiday methods
  getAllHolidays(): Promise<Holiday[]>;
  getHoliday(id: number): Promise<Holiday | undefined>;
  createHoliday(holiday: InsertHoliday): Promise<Holiday>;
  deleteHoliday(id: number): Promise<void>;
  
  // Subject methods
  getAllSubjects(): Promise<Subject[]>;
  getSubject(id: number): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  updateSubject(id: number, subject: Partial<InsertSubject>): Promise<Subject>;
  deleteSubject(id: number): Promise<void>;
  
  // Chapter methods
  getAllChapters(): Promise<Chapter[]>;
  getChapter(id: number): Promise<Chapter | undefined>;
  getChaptersBySubject(subjectId: number): Promise<Chapter[]>;
  createChapter(chapter: InsertChapter): Promise<Chapter>;
  updateChapter(id: number, chapter: Partial<InsertChapter>): Promise<Chapter>;
  deleteChapter(id: number): Promise<void>;
  
  // Test methods
  getAllTests(): Promise<Test[]>;
  getTest(id: number): Promise<Test | undefined>;
  createTest(test: InsertTest): Promise<Test>;
  updateTest(id: number, test: Partial<InsertTest>): Promise<Test>;
  deleteTest(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private holidays: Map<number, Holiday>;
  private subjects: Map<number, Subject>;
  private chapters: Map<number, Chapter>;
  private tests: Map<number, Test>;
  
  private userIdCounter: number;
  private taskIdCounter: number;
  private holidayIdCounter: number;
  private subjectIdCounter: number;
  private chapterIdCounter: number;
  private testIdCounter: number;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.holidays = new Map();
    this.subjects = new Map();
    this.chapters = new Map();
    this.tests = new Map();
    
    this.userIdCounter = 1;
    this.taskIdCounter = 1;
    this.holidayIdCounter = 1;
    this.subjectIdCounter = 1;
    this.chapterIdCounter = 1;
    this.testIdCounter = 1;
    
    // Add a default user
    this.createUser({
      username: "demo",
      password: "password",
      name: "Raj Kumar",
      className: "Class XII",
      examName: "JEE Aspirant",
      photoUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Task methods
  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }
  
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const now = new Date();
    const task: Task = { ...insertTask, id, createdAt: now };
    this.tasks.set(id, task);
    return task;
  }
  
  async updateTask(id: number, updateTask: Partial<InsertTask>): Promise<Task> {
    const task = this.tasks.get(id);
    if (!task) {
      throw new Error(`Task with id ${id} not found`);
    }
    
    const updatedTask = { ...task, ...updateTask };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async deleteTask(id: number): Promise<void> {
    this.tasks.delete(id);
  }
  
  // Holiday methods
  async getAllHolidays(): Promise<Holiday[]> {
    return Array.from(this.holidays.values());
  }
  
  async getHoliday(id: number): Promise<Holiday | undefined> {
    return this.holidays.get(id);
  }
  
  async createHoliday(insertHoliday: InsertHoliday): Promise<Holiday> {
    const id = this.holidayIdCounter++;
    const now = new Date();
    const holiday: Holiday = { ...insertHoliday, id, createdAt: now };
    this.holidays.set(id, holiday);
    return holiday;
  }
  
  async deleteHoliday(id: number): Promise<void> {
    this.holidays.delete(id);
  }
  
  // Subject methods
  async getAllSubjects(): Promise<Subject[]> {
    return Array.from(this.subjects.values());
  }
  
  async getSubject(id: number): Promise<Subject | undefined> {
    return this.subjects.get(id);
  }
  
  async createSubject(insertSubject: InsertSubject): Promise<Subject> {
    const id = this.subjectIdCounter++;
    const now = new Date();
    const subject: Subject = { 
      ...insertSubject, 
      id, 
      mainProgress: 0, 
      advancedProgress: 0,
      createdAt: now 
    };
    this.subjects.set(id, subject);
    return subject;
  }
  
  async updateSubject(id: number, updateSubject: Partial<InsertSubject>): Promise<Subject> {
    const subject = this.subjects.get(id);
    if (!subject) {
      throw new Error(`Subject with id ${id} not found`);
    }
    
    const updatedSubject = { ...subject, ...updateSubject };
    this.subjects.set(id, updatedSubject);
    return updatedSubject;
  }
  
  async deleteSubject(id: number): Promise<void> {
    // Delete all chapters associated with this subject
    const chaptersToDelete = Array.from(this.chapters.values())
      .filter(chapter => chapter.subjectId === id);
    
    for (const chapter of chaptersToDelete) {
      this.chapters.delete(chapter.id);
    }
    
    this.subjects.delete(id);
  }
  
  // Chapter methods
  async getAllChapters(): Promise<Chapter[]> {
    return Array.from(this.chapters.values());
  }
  
  async getChapter(id: number): Promise<Chapter | undefined> {
    return this.chapters.get(id);
  }
  
  async getChaptersBySubject(subjectId: number): Promise<Chapter[]> {
    return Array.from(this.chapters.values())
      .filter(chapter => chapter.subjectId === subjectId);
  }
  
  async createChapter(insertChapter: InsertChapter): Promise<Chapter> {
    const id = this.chapterIdCounter++;
    const now = new Date();
    const chapter: Chapter = { ...insertChapter, id, createdAt: now };
    this.chapters.set(id, chapter);
    
    // Update subject progress
    await this.updateSubjectProgress(insertChapter.subjectId);
    
    return chapter;
  }
  
  async updateChapter(id: number, updateChapter: Partial<InsertChapter>): Promise<Chapter> {
    const chapter = this.chapters.get(id);
    if (!chapter) {
      throw new Error(`Chapter with id ${id} not found`);
    }
    
    const updatedChapter = { ...chapter, ...updateChapter };
    this.chapters.set(id, updatedChapter);
    
    // Update subject progress
    await this.updateSubjectProgress(chapter.subjectId);
    
    return updatedChapter;
  }
  
  async deleteChapter(id: number): Promise<void> {
    const chapter = this.chapters.get(id);
    if (chapter) {
      this.chapters.delete(id);
      // Update subject progress
      await this.updateSubjectProgress(chapter.subjectId);
    }
  }
  
  private async updateSubjectProgress(subjectId: number): Promise<void> {
    const subject = this.subjects.get(subjectId);
    if (!subject) return;
    
    const chapters = await this.getChaptersBySubject(subjectId);
    if (chapters.length === 0) {
      subject.mainProgress = 0;
      subject.advancedProgress = 0;
    } else {
      const completedMainChapters = chapters.filter(ch => ch.isCompletedMain).length;
      const completedAdvancedChapters = chapters.filter(ch => ch.isCompletedAdvanced).length;
      
      subject.mainProgress = Math.round((completedMainChapters / chapters.length) * 100);
      subject.advancedProgress = Math.round((completedAdvancedChapters / chapters.length) * 100);
    }
    
    this.subjects.set(subjectId, subject);
  }
  
  // Test methods
  async getAllTests(): Promise<Test[]> {
    return Array.from(this.tests.values());
  }
  
  async getTest(id: number): Promise<Test | undefined> {
    return this.tests.get(id);
  }
  
  async createTest(insertTest: InsertTest): Promise<Test> {
    const id = this.testIdCounter++;
    const now = new Date();
    
    // Calculate change by comparing with previous test
    const previousTests = Array.from(this.tests.values())
      .filter(t => t.subject === insertTest.subject)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    const previousTest = previousTests[0];
    const previousScore = previousTest ? previousTest.score : 0;
    const change = insertTest.score - previousScore;
    
    const test: Test = { ...insertTest, id, change, createdAt: now };
    this.tests.set(id, test);
    return test;
  }
  
  async updateTest(id: number, updateTest: Partial<InsertTest>): Promise<Test> {
    const test = this.tests.get(id);
    if (!test) {
      throw new Error(`Test with id ${id} not found`);
    }
    
    // If score is being updated, recalculate change
    let change = test.change;
    if (updateTest.score !== undefined) {
      const previousTests = Array.from(this.tests.values())
        .filter(t => t.subject === test.subject && t.id !== id && new Date(t.date) < new Date(test.date))
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      const previousTest = previousTests[0];
      const previousScore = previousTest ? previousTest.score : 0;
      change = updateTest.score - previousScore;
    }
    
    const updatedTest = { ...test, ...updateTest, change };
    this.tests.set(id, updatedTest);
    
    // Update change for subsequent tests
    if (updateTest.score !== undefined) {
      const subsequentTests = Array.from(this.tests.values())
        .filter(t => t.subject === test.subject && new Date(t.date) > new Date(test.date))
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
      let lastScore = updatedTest.score;
      for (const subTest of subsequentTests) {
        const newChange = subTest.score - lastScore;
        this.tests.set(subTest.id, { ...subTest, change: newChange });
        lastScore = subTest.score;
      }
    }
    
    return updatedTest;
  }
  
  async deleteTest(id: number): Promise<void> {
    const testToDelete = this.tests.get(id);
    if (!testToDelete) return;
    
    this.tests.delete(id);
    
    // Recalculate change for subsequent tests
    const subsequentTests = Array.from(this.tests.values())
      .filter(t => t.subject === testToDelete.subject && new Date(t.date) > new Date(testToDelete.date))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    if (subsequentTests.length === 0) return;
    
    // Find previous test before the first subsequent test
    const firstTest = subsequentTests[0];
    const previousTests = Array.from(this.tests.values())
      .filter(t => t.subject === firstTest.subject && new Date(t.date) < new Date(firstTest.date))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    const previousScore = previousTests.length > 0 ? previousTests[0].score : 0;
    
    // Update changes for all subsequent tests
    let lastScore = previousScore;
    for (const test of subsequentTests) {
      const newChange = test.score - lastScore;
      this.tests.set(test.id, { ...test, change: newChange });
      lastScore = test.score;
    }
  }
}

export const storage = new MemStorage();
