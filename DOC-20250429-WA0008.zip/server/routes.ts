import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema, insertHolidaySchema, insertSubjectSchema, insertChapterSchema, insertTestSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // Tasks API
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getAllTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tasks" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const task = insertTaskSchema.parse(req.body);
      const newTask = await storage.createTask(task);
      res.status(201).json(newTask);
    } catch (error) {
      res.status(400).json({ message: "Invalid task data" });
    }
  });

  app.put("/api/tasks/:id", async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = insertTaskSchema.partial().parse(req.body);
      const updatedTask = await storage.updateTask(taskId, task);
      res.json(updatedTask);
    } catch (error) {
      res.status(400).json({ message: "Invalid task data" });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      await storage.deleteTask(taskId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting task" });
    }
  });

  // Holidays API
  app.get("/api/holidays", async (req, res) => {
    try {
      const holidays = await storage.getAllHolidays();
      res.json(holidays);
    } catch (error) {
      res.status(500).json({ message: "Error fetching holidays" });
    }
  });

  app.post("/api/holidays", async (req, res) => {
    try {
      const holiday = insertHolidaySchema.parse(req.body);
      const newHoliday = await storage.createHoliday(holiday);
      res.status(201).json(newHoliday);
    } catch (error) {
      res.status(400).json({ message: "Invalid holiday data" });
    }
  });

  app.delete("/api/holidays/:id", async (req, res) => {
    try {
      const holidayId = parseInt(req.params.id);
      await storage.deleteHoliday(holidayId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting holiday" });
    }
  });

  // Subjects API
  app.get("/api/subjects", async (req, res) => {
    try {
      const subjects = await storage.getAllSubjects();
      res.json(subjects);
    } catch (error) {
      res.status(500).json({ message: "Error fetching subjects" });
    }
  });

  app.post("/api/subjects", async (req, res) => {
    try {
      const subject = insertSubjectSchema.parse(req.body);
      const newSubject = await storage.createSubject(subject);
      res.status(201).json(newSubject);
    } catch (error) {
      res.status(400).json({ message: "Invalid subject data" });
    }
  });

  app.put("/api/subjects/:id", async (req, res) => {
    try {
      const subjectId = parseInt(req.params.id);
      const subject = insertSubjectSchema.partial().parse(req.body);
      const updatedSubject = await storage.updateSubject(subjectId, subject);
      res.json(updatedSubject);
    } catch (error) {
      res.status(400).json({ message: "Invalid subject data" });
    }
  });

  app.delete("/api/subjects/:id", async (req, res) => {
    try {
      const subjectId = parseInt(req.params.id);
      await storage.deleteSubject(subjectId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting subject" });
    }
  });

  // Chapters API
  app.get("/api/subjects/:subjectId/chapters", async (req, res) => {
    try {
      const subjectId = parseInt(req.params.subjectId);
      const chapters = await storage.getChaptersBySubject(subjectId);
      res.json(chapters);
    } catch (error) {
      res.status(500).json({ message: "Error fetching chapters" });
    }
  });

  app.post("/api/subjects/:subjectId/chapters", async (req, res) => {
    try {
      const subjectId = parseInt(req.params.subjectId);
      const chapter = insertChapterSchema.parse({ ...req.body, subjectId });
      const newChapter = await storage.createChapter(chapter);
      res.status(201).json(newChapter);
    } catch (error) {
      res.status(400).json({ message: "Invalid chapter data" });
    }
  });

  app.put("/api/chapters/:id", async (req, res) => {
    try {
      const chapterId = parseInt(req.params.id);
      const chapter = insertChapterSchema.partial().parse(req.body);
      const updatedChapter = await storage.updateChapter(chapterId, chapter);
      res.json(updatedChapter);
    } catch (error) {
      res.status(400).json({ message: "Invalid chapter data" });
    }
  });

  app.delete("/api/chapters/:id", async (req, res) => {
    try {
      const chapterId = parseInt(req.params.id);
      await storage.deleteChapter(chapterId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting chapter" });
    }
  });

  // Tests API
  app.get("/api/tests", async (req, res) => {
    try {
      const tests = await storage.getAllTests();
      res.json(tests);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tests" });
    }
  });

  app.post("/api/tests", async (req, res) => {
    try {
      const test = insertTestSchema.parse(req.body);
      const newTest = await storage.createTest(test);
      res.status(201).json(newTest);
    } catch (error) {
      res.status(400).json({ message: "Invalid test data" });
    }
  });

  app.put("/api/tests/:id", async (req, res) => {
    try {
      const testId = parseInt(req.params.id);
      const test = insertTestSchema.partial().parse(req.body);
      const updatedTest = await storage.updateTest(testId, test);
      res.json(updatedTest);
    } catch (error) {
      res.status(400).json({ message: "Invalid test data" });
    }
  });

  app.delete("/api/tests/:id", async (req, res) => {
    try {
      const testId = parseInt(req.params.id);
      await storage.deleteTest(testId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting test" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
